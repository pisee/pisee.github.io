from rest_framework import serializers

from .models import Visit, VisitUser, VisitCar

class VisitSerializer(serializers.ModelSerializer):
    class Meta:
        model = Visit
        fields = "__all__"

class VisitUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = VisitUser
        fields = "__all__"

class VisitCarSerializer(serializers.ModelSerializer):
    class Meta:
        model = VisitCar
        fields = "__all__"

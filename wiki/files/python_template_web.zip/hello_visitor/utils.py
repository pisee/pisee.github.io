import re

def to_camel_case(snake_str):
    components = snake_str.split('_')
    return components[0] + "".join(x.title() for x in components[1:])


def camel_case_data(data):
    if isinstance(data, list):
        return [camel_case_data(each) for each in data]

    if isinstance(data, dict):
        return {to_camel_case(key): camel_case_data(value) for key, value in data.items()}

    return data

_first_cap_re = re.compile('(.)([A-Z][a-z]+)')
_all_cap_re = re.compile('([a-z0-9])([A-Z])')


def to_snake_case(word):
    s1 = _first_cap_re.sub(r'\1_\2', word)
    return _all_cap_re.sub(r'\1_\2', s1).lower()

def snake_case_data(data):
    if isinstance(data, list):
        return [snake_case_data(each) for each in data]

    if isinstance(data, dict):
        return {to_snake_case(key): snake_case_data(value) for key, value in data.items()}

    return data


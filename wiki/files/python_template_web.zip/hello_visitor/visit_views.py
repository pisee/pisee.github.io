from rest_framework.views import APIView
from rest_framework.response import Response

from hello_visitor.models import Visit, VisitUser, VisitCar
from .serializers import *

from hello_common.models import User
from hello_common.serializers import UserSerializer

from django.db import connection

from django.db import connection

class VisitList(APIView):
    def get(self, request):
        print('# session key ', request.session.session_key);
        print('# request : ', request.GET)
        
        resp_dict = self.list_visit(request.GET)
        #print('# resp : ', resp_dict)
        
        return Response(resp_dict)
    
    def post(self, request):
        print('# request data visit : ', request.data) #dictionary
        v_ser = self.create_visit(request.data)
        print('# visit_id ', v_ser.data['visit_id'])
        
        return Response({"visitId": v_ser.data['visit_id']})
        

    def list_visit(self, data):
        visit_request_user_id = data.get('visitRequestUserId', '') #신청자
        visit_response_user_id = data.get('visitResponseUserId', '') #접견자
        visit_status_id = data.get('visitStatusId', '') #상태
        visit_start_date = data.get('visitStartDate', '') #방문기간
        
        size = int(data.get('size', '0'))
        offset = int(data.get('page', '0'))*size
        limit = offset+size

        qs = Visit.objects.filter(delete_yn='N')
        
        #dynamic sql
        if visit_request_user_id != '':
            qs = qs.filter(visit_request_user_id=visit_request_user_id)
        if visit_response_user_id != '':
            qs = qs.filter(visit_response_user_id=visit_response_user_id)
        if visit_status_id != '' and visit_status_id != '0':
            qs = qs.filter(visit_status_id=visit_status_id)
        if visit_start_date != '':
            qs = qs.filter(visit_start_date__gte=visit_start_date)
        
        tot_cnt = qs.count()
        
        #order by
        qs = qs.order_by('-visit_id')

        # paging
        qs = qs[offset:limit]
        print('# sql : ', qs.query) 
        
        visit_list = []
        for row in qs:
            row_dict = VisitSerializer(row).data 	#serializer : model object => dict
            row_dict['visitUsersCnt'] = VisitUser.objects.filter(visit_id=row.visit_id).count()
            row_dict['visitCarsCnt'] = VisitCar.objects.filter(visit_id=row.visit_id).count()
            #print('# row dict', row_dict)
            
            visit_list.append(row_dict)
            
        tot_page = int(tot_cnt / int(data.get('size', '0')))+1
        
        resp_dict = {'content': visit_list, 'totalPages' : tot_page, 'totalElements': tot_cnt}
        return resp_dict

    def create_visit(self, req_data):
        v_dict = req_data
        v_dict['create_user_id'] = v_dict['visit_request_user_id']
        v_dict['update_user_id'] = v_dict['visit_request_user_id']
        v_dict['visit_notice_user_id'] = v_dict['visit_response_user_id']
        #print('# v_dict ', v_dict)
        
        v_ser = VisitSerializer(data=v_dict) 	#serializer : dict => serializer
        v_ser.is_valid()
        v_ser.save()
        
        return v_ser

class VisitDetail(APIView):
    def get(self, request, pk):
        print('# request : ', request.GET)
        
        visit_detail = self.select_visit_by_pk(pk, request.GET)
        print('# resp : ', visit_detail)
        
        return Response(visit_detail)
        
    def delete(self, request, pk):
        self.delete_visit(pk)
        return Response({}) 
        
    def select_visit_by_pk(self, pk, data):
        visit = Visit.objects.get(visit_id=pk)
        
        visit_detail = VisitSerializer(visit).data		#serializer : model object => dict
        
        vu_list = visit.visituser_set.all()
        vu_dic_list = VisitUserSerializer(vu_list, many=True).data
        
        visit_detail['visitUsers'] = vu_dic_list
        
        vc_list = visit.visitcar_set.all()
        vc_dic_list = VisitCarSerializer(vc_list, many=True).data
        visit_detail['visitCars'] = vc_dic_list
        
        return visit_detail
        
    def delete_visit(self, pk):
        visit = Visit.objects.get(visit_id=pk)
        visit.delete()

class VisitStatusUpdate(APIView):
    #def post(self, request, pk, status_id):
    def put(self, request, pk, status_id):
        self.update_visit_status(pk, status_id)
        
        return Response({})
        
    def update_visit_status(self, pk, status_id):
        visit = Visit.objects.get(visit_id=pk)
        
        visit_ser_data = VisitSerializer(visit).data
        visit_ser_data['visit_status_id'] = status_id

        visit_serial = VisitSerializer(visit, data=visit_ser_data)
        
        if visit_serial.is_valid():
            visit_serial.save()
        else:
            raise Exception('vaild error')
        
class VisitCreateUser(APIView):
    def post(self, request):
        print('# request data user : ', request.data) #dictionary
        
        self.create_visit_user(request.data)
        return Response({})

    def create_visit_user(self, req_data):
        for row in req_data:
            visit_id = row.get('visit_id', 0)
            vu_dict = row
            vu_dict['visit'] = visit_id
            #print('# vu_dict ', vu_dict)
            
            vu_ser = VisitUserSerializer(data=vu_dict) 	#serializer : dict => serializer
            vu_ser.is_valid()
            vu_ser.save()
            
class VisitCreateCar(APIView):
    def post(self, request):
        print('# request data car : ', request.data) #dictionary
        self.create_visit_car(request.data)
        return Response({})

    # transaction test
    
    def create_visit_car(self, req_data):
        for row in req_data:
            visit_id = row.get('visit_id', 0)
            vc_dict = row
            vc_dict['visit'] = visit_id
            #print('# vc_dict ', vc_dict)
            
            vc_ser = VisitCarSerializer(data=vc_dict) 	#serializer : dict => serializer
            vc_ser.is_valid()
            vc_ser.save()
            
class VisitCreateMail(APIView):
    def post(self, request):
        return Response({})

class StaffUserFind(APIView):
    def get(self, request):
        search_text = request.GET.get('searchText', '')
        user_list = User.objects.filter(full_name__contains=search_text)
        user_dic_list = UserSerializer(user_list, many=True).data
        return Response(user_dic_list)



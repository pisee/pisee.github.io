from django.contrib import admin

from .models import Visit, VisitUser, VisitCar

admin.site.register(Visit)
admin.site.register(VisitUser)
admin.site.register(VisitCar)

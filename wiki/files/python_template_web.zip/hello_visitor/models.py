from django.db import models

from django.db import migrations

class Migration(migrations.Migration):
    atomic = False

class Visit(models.Model):
    visit_id = models.AutoField(primary_key=True)
    
    visit_status_id = models.BigIntegerField(default=1)
    visit_request_user_id = models.BigIntegerField()
    visit_request_user_full_name = models.CharField(max_length=100)
    visit_response_user_id = models.BigIntegerField()
    visit_response_user_full_name = models.CharField(max_length=100)
    visit_notice_user_id = models.BigIntegerField(default=0)
    visit_start_date = models.DateTimeField(auto_now=True)
    visit_end_date = models.DateTimeField(auto_now=True)
    visit_purpose = models.CharField(max_length=100)
    visit_purpose_detail = models.CharField(max_length=500)
    visit_place = models.CharField(max_length=100)
    
    delete_yn = models.CharField(max_length=50, default='N')
    create_user_id = models.BigIntegerField()
    create_date = models.DateTimeField(null=True)
    update_user_id = models.BigIntegerField()
    update_date = models.DateTimeField(null=True)
    
    def __str__(self):
        return str(self.visit_id)
    
    class Meta:
        db_table = ('TBL_VISIT')


class VisitUser(models.Model):
    visit_user_id = models.AutoField(primary_key=True)
    visit = models.ForeignKey(Visit, on_delete=models.CASCADE, db_column='VISIT_ID')
    
    visit_user_full_name = models.CharField(max_length=50)
    visit_user_nationality = models.CharField(max_length=50)
    visit_user_gender = models.CharField(max_length=20)
    visit_user_grade = models.CharField(max_length=100)
    visit_user_phone = models.CharField(max_length=20)
    visit_user_email = models.CharField(max_length=30)
    visit_user_company = models.CharField(max_length=100)
    
    delete_yn = models.CharField(max_length=50, default='N')
    create_user_id = models.BigIntegerField()
    create_date = models.DateTimeField(null=True)
    update_user_id = models.BigIntegerField()
    update_date = models.DateTimeField(null=True)
    
    class Meta:
        db_table = ('TBL_VISIT_USER')

class VisitCar(models.Model):
    visit_car_id = models.AutoField(primary_key=True)
    visit = models.ForeignKey(Visit, on_delete=models.CASCADE, db_column='VISIT_ID')
    
    visit_car_hour = models.CharField(max_length=3)
    visit_car_minute = models.CharField(max_length=3)
    visit_car_time = models.DateTimeField(null=True)
    visit_car_number = models.CharField(max_length=20)
    visit_car_category = models.CharField(max_length=50)
    visit_car_model = models.CharField(max_length=50)
    visit_car_purpose = models.CharField(max_length=100)
    visit_car_gate = models.CharField(max_length=50)
    
    delete_yn = models.CharField(max_length=50, default='N')
    create_user_id = models.BigIntegerField()
    create_date = models.DateTimeField(null=True)
    update_user_id = models.BigIntegerField()
    update_date = models.DateTimeField(null=True)
    
    class Meta:
        db_table = ('TBL_VISIT_CAR')

        

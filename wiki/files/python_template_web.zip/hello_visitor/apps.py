from django.apps import AppConfig


class HelloVisitorConfig(AppConfig):
    name = 'hello_visitor'

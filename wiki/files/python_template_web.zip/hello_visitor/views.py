from rest_framework.views import APIView
from rest_framework.response import Response
from django.http import HttpResponse
from django.http import JsonResponse

from rest_framework.decorators import api_view

from django.db import connection

from .models import Visit, VisitUser, VisitCar

from django.contrib.auth import authenticate, login

from rest_framework import mixins
from rest_framework import generics

from .serializers import VisitSerializer

# native sql example
class VisitListSqlExam(APIView):
    def get(self, request):
        print('# user name  : ', request.session.get('username', 'no session'))
        print('# sess info  : %s, %s' %(request.session.session_key, request.session.keys()))
        print('# auth, user : %s, %s' %(request.auth, request.user))
    
        print('# request : ', request.GET)
        #ex) {'page': ['0'], 'size': ['15'], 'visitStatusId': [''], 'visitRequestUserId': ['2']}
        
        visit_list = self.list_visit(request.GET)
        resp_dict = {'content': visit_list, 'totalPages' : 1, 'totalElements': 1}
        #print('# resp : ', resp_dict)
        
        return Response(resp_dict)

    def list_visit(self, data):
        sql_header = '''
        SELECT V.VISIT_ID
        , V.VISIT_REQUEST_USER_ID
        , V.VISIT_REQUEST_USER_FULL_NAME             
        , V.VISIT_RESPONSE_USER_ID
        , V.VISIT_RESPONSE_USER_FULL_NAME
        , V.VISIT_START_DATE
        , V.VISIT_END_DATE
        , V.VISIT_PURPOSE
        , V.VISIT_PURPOSE_DETAIL
        , V.VISIT_PLACE
        , V.VISIT_STATUS_ID
        , (SELECT COUNT(1) FROM TBL_VISIT_USER WHERE VISIT_ID = V.VISIT_ID) AS VISIT_USERS_CNT
        , (SELECT COUNT(1) FROM TBL_VISIT_CAR WHERE VISIT_ID = V.VISIT_ID) AS VISIT_CARS_CNT
        FROM TBL_VISIT V
        WHERE DELETE_YN = 'N'
        '''
        
        args = []
        sql_stmts = [sql_header]
        
        # start dynamic sql
        visit_request_user_id = data.get('visitRequestUserId', '0')
        if visit_request_user_id != '':
            sql_stmts.append('AND V.VISIT_REQUEST_USER_ID = %s \n')
            args.append(visit_request_user_id)
            
        
        #order by and paging
        sql_stmts.append("ORDER BY V.VISIT_ID DESC \n")
        sql_stmts.append("LIMIT %s OFFSET %s \n")
        
        limit = int(data.get('size', '0'))
        offset = int(data.get('page', '0'))*limit

        args.append(limit)
        args.append(offset)

        sql = ''.join(sql_stmts)
        print('# sql : ', sql)

        with connection.cursor() as cursor:
            cursor.execute(sql, args)
            visit_list = []  #dictionary list
            for row in cursor.fetchall():
                visit_dic    = {
                    'visitId': row[0],
                    'visitRequestUserId' : row[1],
                    'visitRequestUserFullName': row[2],
                    'visitResponseUserId' : row[3],
                    'visitResponseUserFullName': row[4],
                    'visitStartDate': row[5],
                    'visitEndDate':row[6],
                    'visitPurpose': row[7],
                    'visitPurposeDetail': row[8],
                    'visitPlace': row[9],
                    'visitStatusId': row[10],
                    'visitUsersCnt': row[11],
                    'visitCarsCnt':row[12],
                }
                visit_list.append(visit_dic)

        return visit_list


# mixin, generic view example
#class VisitListMViewExam(generics.ListCreateAPIView):
class VisitListMViewExam(mixins.ListModelMixin,
                  mixins.CreateModelMixin,
                  generics.GenericAPIView):
    queryset = Visit.objects.first()
    serializer_class = VisitSerializer

    def get_queryset(self):
        queryset = Visit.objects.all()
        visit_id = self.request.query_params.get('visit_id', None)
        if visit_id is not None:
            queryset = queryset.filter(visit_id=visit_id)
            
        return queryset

    def list(self, request):
        qs = self.get_queryset()
        serializer = self.serializer_class(qs, many=True)
        return Response(serializer.data)        
        
    def create(self, request):
        serializer_data = request.data

        serializer = self.serializer_class(data=serializer_data)
        serializer.is_valid(raise_exception=True)
        serializer.save()

        return Response(serializer.data)
    
    def get(self, request, *args, **kwargs):
        print('# snippet get ')
        return self.list(request, *args, **kwargs)

    def post(self, request, *args, **kwargs):
        return self.create(request, *args, **kwargs)

#class VisitDetailMViewExam(generics.RetrieveUpdateDestroyAPIView): 
class VisitDetailMViewExam(mixins.RetrieveModelMixin,
                    mixins.UpdateModelMixin,
                    mixins.DestroyModelMixin,
                    generics.GenericAPIView):
    queryset = Visit.objects.all()
    serializer_class = VisitSerializer

    def get(self, request, *args, **kwargs):
        return self.retrieve(request, *args, **kwargs)

    def put(self, request, *args, **kwargs):
        return self.update(request, *args, **kwargs)

    def delete(self, request, *args, **kwargs):
        return self.destroy(request, *args, **kwargs)

# no CamelCaseFormParser
class VisitListNoCamelExam(APIView):
    def post(self, request):
        pass
    def get(self, request):
        print('# request : ', request.GET)
        #ex)<QueryDict: {'page': ['0'], 'size': ['15'], 'visitStartDate': ['2019-02-28T15:00:00.000Z'], 'visitEndDate': ['2019-03-01T14:59:59.000Z'], ...
        
        resp_dict = self.list_visit(request.GET)
        #print('# resp : ', resp_dict)
        
        return Response(resp_dict)

    def list_visit(self, data):
        visit_request_user_id = data.get('visitRequestUserId', '') #신청자
        visit_response_user_id = data.get('visitResponseUserId', '') #접견자
        visit_status_id = data.get('visitStatusId', '') #상태
        visit_start_date = data.get('visitStartDate', '') #방문기간
        
        limit = int(data.get('size', '0'))
        offset = int(data.get('page', '0'))*limit

        qs = Visit.objects.filter(delete_yn='N')
        
        #dynamic sql
        if visit_request_user_id != '':
            qs = qs.filter(visit_request_user_id=visit_request_user_id)
        if visit_response_user_id != '':
            qs = qs.filter(visit_response_user_id=visit_response_user_id)
        if visit_status_id != '' and visit_status_id != '0':
            qs = qs.filter(visit_status_id=visit_status_id)
        #time 관련 더 확인 필요
        if visit_start_date != '':
            qs = qs.filter(visit_start_date__gte=visit_start_date)
        
        tot_cnt = qs.count()
        
        #order by
        qs = qs.order_by('-visit_id')
        
        # paging
        qs = qs[offset:limit]
        print('# sql : ', qs.query) 
        
        visit_list = []
        for row in qs:
            visit_users_cnt = VisitUser.objects.filter(visit_id=row.visit_id).count()
            visit_cars_cnt = VisitCar.objects.filter(visit_id=row.visit_id).count()
            
            visit_dic    = {
                'visitId': row.visit_id,
                'visitRequestUserId' : row.visit_request_user_id,
                'visitRequestUserFullName': row.visit_request_user_full_name,
                'visitResponseUserId' : row.visit_response_user_id,
                'visitResponseUserFullName': row.visit_response_user_full_name,
                'visitStartDate': row.visit_start_date,
                'visitEndDate': row.visit_end_date,
                'visitPurpose': row.visit_purpose,
                'visitPurposeDetail': row.visit_purpose_detail,
                'visitPlace': row.visit_place,
                'visitStatusId': row.visit_status_id,
                'visitUsersCnt': visit_users_cnt,
                'visitCarsCnt':visit_cars_cnt,
            }
            visit_list.append(visit_dic)
        
        tot_page = int(tot_cnt / int(data.get('size', '0')))+1
        
        resp_dict = {'content': visit_list, 'totalPages' : tot_page, 'totalElements': tot_cnt}
        return resp_dict

# function base view example
@api_view(['GET','POST'])
def visit_list_func_exam(request):
    if request.method == 'GET':
        print('# request : ', request.GET)
        visit_id = request.GET.get('visit_id', '')
        qs = Visit.objects.filter(visit_id=visit_id)
        vs = VisitSerializer(qs, many=True)
        return Response(vs.data)
    elif request.method == 'POST':
        return Response({})

def index(request):
    return HttpResponse('<p>hello visitor !</p>')

@api_view(['POST'])
def login(request):
    req_data = request.data
    
    username = req_data.get('username', 'nousername')
    password = req_data.get('password', 'nopassword')  #ex) admin/admin
    print('# log info : %s, %s' %(username, password))
    
    user = authenticate(username=username, password=password)
    if user is not None:
        print('# authenticate ok')
        request.session['username'] = username
    else:
        print('# authenticate not ok')
        raise Exception('# authenticate error')
        
    return Response({})

@api_view(['GET','POST'])
def logout(request):
    request.session.flush()
    
    return Response({})


from django.urls import path
from rest_framework.urlpatterns import format_suffix_patterns

from hello_visitor import visit_views

from hello_visitor import views

urlpatterns = [
    path('api/v1/visits/history', visit_views.VisitList.as_view()),
    path('api/v1/visits/approval', visit_views.VisitList.as_view()),
    path('api/v1/visits', visit_views.VisitList.as_view()),		#list, post
    
    path('api/v1/visits/user', visit_views.VisitCreateUser.as_view()),
    path('api/v1/visits/car', visit_views.VisitCreateCar.as_view()),
    path('api/v1/visits/mail', visit_views.VisitCreateMail.as_view()),
    
    path('api/v1/visits/<int:pk>', visit_views.VisitDetail.as_view()),	#get, delete
    path('api/v1/visits/<int:pk>/<int:status_id>', visit_views.VisitStatusUpdate.as_view()),
    
    path('api/v1/users/search', visit_views.StaffUserFind.as_view()),
    path('api/v1/users/search/staff', visit_views.StaffUserFind.as_view()),
    
    
    path('', views.index),
]


'''
	#exmple
    #path('login', views.login),
    #path('logout', views.logout),
    
    #example : native sql
    #path('visit/list', views.VisitListSqlExam.as_view()),

    #example : mixin, generic views
    #path('visit/list', views.VisitListMViewExam.as_view()),
    #path('visit/detail/<int:pk>', views.VisitDetailMViewExam.as_view()),
    
	#example : no CamelCaseFormParser
	#path('visit/list', views.VisitListNoCamelExam.as_view()),

    #example : function base view
    #path('visit/list', views.visit_list_func_exam),
'''



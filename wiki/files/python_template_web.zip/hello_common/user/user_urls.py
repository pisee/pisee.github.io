from django.urls import path
from hello_common.user import user_views

urlpatterns = [
    path('api/v1/users', user_views.save_user),
    path('api/v1/users/bulk', user_views.save_user_bulk),
    path('api/v1/users/search/find-login', user_views.find_login),
    path('api/v1/users/search/check-password', user_views.check_password),
    path('api/v1/users/validate', user_views.validate_user),
    path('api/v1/users/exist/<str:login>', user_views.get_user_status),
    path('api/v1/users/management/<str:login>', user_views.get_user_management),
    path('api/v1/users/<str:login>/password/', user_views.change_password),
    path('api/v1/users/<str:login>/password/force', user_views.change_password_force),
    path("api/v1/users/<str:login>", user_views.dispatch_user),

]


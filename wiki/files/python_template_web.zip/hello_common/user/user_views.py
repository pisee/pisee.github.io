from django.utils import timezone
from rest_framework import status
from django.http import Http404, HttpResponseBadRequest

from rest_framework.response import Response

from rest_framework.decorators import api_view

from hello_common.models import User, RoleUser
from hello_common.serializers import UserSerializer
from hello_common.rsa_cipher import RsaCipher


@api_view(['GET'])
def get_user_status(request, login):
    queryset = User.objects.filter(login=login)
    try:
        user = queryset.get()
    except User.DoesNotExist:
        return Response('none')
    if user is not None:
        if user.delete_yn == 'N':
            return Response('VISIT')
        else:
            return Response('DELETED')


@api_view(['GET'])
def get_user_management(request, login):
    return Response(status=status.HTTP_501_NOT_IMPLEMENTED)


def create_user(user_dict):
    count = User.objects.filter(login=user_dict['login']).count()
    if count > 0:
        return HttpResponseBadRequest()

    user_dict['status_id'] = 1
    decrypt_auth_code = RsaCipher.rsa_decrypt(user_dict['auth_code'])
    hashed_auth_code = RsaCipher.bytes_to_bcrypt(decrypt_auth_code)
    user_auth_code = hashed_auth_code.decode('utf-8')
    user_dict['auth_code'] = user_auth_code
    user_dict['create_user_id'] = 1

    user_serializer = UserSerializer(data=user_dict)  # serializer : dict => serializer
    if user_serializer.is_valid():
        user_serializer.save()

        user = User.objects.filter(login=user_dict['login']).get()
        role_user = RoleUser.objects.create(user_id=user.user_id, role_id=3)
        print(user, role_user)
    else:
        print(user_serializer.errors)
        return HttpResponseBadRequest()
    return Response()


@api_view(['POST', 'PUT'])
def save_user(request):
    if request.method == 'POST':
        return create_user(request.data)
    elif request.metho == 'PUT':
        return Response(status=status.HTTP_501_NOT_IMPLEMENTED)


@api_view(['POST'])
def save_user_bulk(request):
    return Response(status=status.HTTP_501_NOT_IMPLEMENTED)


def update_user(user_dict):
    user_id = user_dict['user_id']
    user = User.objects.filter(user_id=user_id).get()

    if is_equal_auth_code(user_dict['auth_code'], user.auth_code):
        user.full_name = user_dict['full_name']
        user.email = user_dict['email']
        user.company = user_dict['company']
        user.grade = user_dict['grade']
        user.nationality = user_dict['nationality']
        user.contact_no = user_dict['contact_no']
        user.gender = user_dict['gender']
        user.locale = user_dict['locale']
        user.timezone = user_dict['timezone']
        user.update_user_id = 1
        user.update_date = timezone.now()
        user.save()
        return Response(status=status.HTTP_200_OK)
    else:
        return Response(status=status.HTTP_403_FORBIDDEN)


def is_equal_auth_code(req_auth_code, user_auth_code):
    decrypt_auth_code = RsaCipher.rsa_decrypt(req_auth_code)
    hashed_auth_code = RsaCipher.bytes_to_bcrypt(decrypt_auth_code)
    user_auth_code = user_auth_code.encode('utf-8')
    return user_auth_code == hashed_auth_code


@api_view(['GET', 'PUT', 'DELETE'])
def dispatch_user(request, login):
    if request.method == 'GET':
        return get_user(login)
    elif request.method == 'PUT':
        return update_user(request.data)
    elif request.method == 'DELETE':
        return Response(status=status.HTTP_501_NOT_IMPLEMENTED)


def get_user(login):
    queryset = User.objects.filter(login=login, delete_yn='N').values("user_id", "login", "full_name", "email", "locale"
                                                                      , "timezone", "datetime_pattern", "status_id",
                                                                      "login_fail_count", "last_auth_code_update_date",
                                                                      "company", "nationality", "grade", "contact_no",
                                                                      "gender", "approval_id", "delete_yn", "create_user_id",
                                                                      "create_date", "update_user_id", "update_date")
    try:
        user = queryset.get()
    except User.DoesNotExist:
        raise Http404("User does not exist")
    return Response(user)


@api_view(['GET'])
def find_login(request):
    full_name = request.query_params.get('fullName', None)
    email = request.query_params.get('email', None)
    print(full_name, email)
    try:
        user = User.objects.filter(full_name=full_name, email=email, delete_yn='N').get()
        return Response(user.login)
    except User.DoesNotExist:
        return Response()


@api_view(['GET'])
def check_password(request):
    login = request.query_params.get('login', None)
    full_name = request.query_params.get('fullName', None)
    email = request.query_params.get('email', None)
    print(full_name, email)
    try:
        User.objects.filter(login=login, full_name=full_name, email=email, delete_yn='N').get()
        return Response()
    except User.DoesNotExist:
        return Http404("User does not exist")


@api_view(['POST'])
def validate_user(request):
    return Response(status=status.HTTP_501_NOT_IMPLEMENTED)


@api_view(['PATCH'])
def change_password(request, login):
    return Response(status=status.HTTP_501_NOT_IMPLEMENTED)


@api_view(['PATCH'])
def change_password_force(request, login):
    full_name = request.data['full_name']
    email = request.data['email']
    print(login, full_name, email)
    print(request.data)
    return Response();


from django.db import models
from compositefk.fields import CompositeOneToOneField, LocalFieldValue, RawFieldValue


class Access(models.Model):
    access_id = models.AutoField(primary_key=True)
    user_id = models.BigIntegerField()
    access_ip = models.CharField(max_length=100)
    description = models.CharField(max_length=1500, null=True)
    use_yn = models.CharField(max_length=1)
    create_user_id = models.BigIntegerField()
    create_date = models.DateTimeField(auto_now=True)
    update_user_id = models.BigIntegerField(null=True)
    update_date = models.DateTimeField(null=True)

    class Meta:
        db_table = ('TBL_ACCESS')


class Message(models.Model):
    message_group = models.CharField(max_length=50)
    message_code = models.CharField(max_length=100)
    ko = models.CharField(max_length=3000, null=True)
    en = models.CharField(max_length=3000, null=True)
    zh = models.CharField(max_length=3000, null=True)
    ja = models.CharField(max_length=100, null=True)
    vi = models.CharField(max_length=100, null=True)
    fr = models.CharField(max_length=100, null=True)
    de = models.CharField(max_length=100, null=True)
    es = models.CharField(max_length=100, null=True)
    it = models.CharField(max_length=100, null=True)
    l1 = models.CharField(max_length=100, null=True)
    l2 = models.CharField(max_length=100, null=True)
    l3 = models.CharField(max_length=100, null=True)
    create_user_id = models.BigIntegerField()
    create_date = models.DateTimeField(auto_now=True)
    update_user_id = models.BigIntegerField(null=True)
    update_date = models.DateTimeField(null=True)

    class Meta:
        db_table = ('TBL_MESSAGE')
        unique_together = (('message_group', 'message_code'),)


class CodeGroup(models.Model):
    group_id = models.AutoField(primary_key=True)
    group_key = models.CharField(max_length=50, null=True)
    default_name = models.CharField(max_length=400, null=True)
    message_group = models.CharField(max_length=50, null=True)
    message_code = models.CharField(max_length=100, null=True)
    use_yn = models.CharField(max_length=1, null=True)
    create_user_id = models.BigIntegerField()
    create_date = models.DateTimeField(auto_now=True)
    update_user_id = models.BigIntegerField(null=True)
    update_date = models.DateTimeField(null=True)
    message = CompositeOneToOneField(Message, on_delete=models.CASCADE, to_fields={
        'message_group': LocalFieldValue('message_group'),
        'message_code': LocalFieldValue('message_code')
    })

    class Meta:
        db_table = ('TBL_CODE_GROUP')


class CodeDetail(models.Model):
    code_id = models.AutoField(primary_key=True)
    code_key = models.CharField(max_length=50, null=True)
    default_name = models.CharField(max_length=400, null=True)
    message_group = models.CharField(max_length=50, null=True)
    message_code = models.CharField(max_length=100, null=True)
    code_order = models.BigIntegerField(null=True)
    use_yn = models.CharField(max_length=1, null=True)
    create_user_id = models.BigIntegerField()
    create_date = models.DateTimeField(auto_now=True)
    update_user_id = models.BigIntegerField(null=True)
    update_date = models.DateTimeField(null=True)
    group = models.ForeignKey(CodeGroup, to_field="group_id", db_column="group_id", on_delete=models.CASCADE)
    message = CompositeOneToOneField(Message, on_delete=models.CASCADE, to_fields={
        'message_group': LocalFieldValue('message_group'),
        'message_code' : LocalFieldValue('message_code')
    })

    class Meta:
        db_table = ('TBL_CODE_DETAIL')


class Terms(models.Model):
    terms_key = models.CharField(max_length=100)
    terms_name = models.CharField(max_length=1000, null=True)
    version = models.BigIntegerField()
    locale = models.CharField(max_length=50)
    mandatory_yn = models.CharField(max_length=1)
    contents = models.TextField()
    published_yn = models.CharField(max_length=1)
    published_date = models.DateTimeField()
    create_user_id = models.BigIntegerField()
    create_date = models.DateTimeField(auto_now=True, null=True)
    update_user_id = models.BigIntegerField(null=True)
    update_date = models.DateTimeField(null=True)

    class Meta:
        db_table = ('TBL_TERMS')
        unique_together = (('terms_key', 'version', 'locale'),)


class Group(models.Model):
    group_id = models.AutoField(primary_key=True)
    group_name = models.CharField(max_length=100)
    description = models.CharField(max_length=1500, null=True)
    use_yn = models.CharField(max_length=1, default='Y')
    create_user_id = models.BigIntegerField(null=True)
    create_date = models.DateTimeField(auto_now=True, null=True)
    update_user_id = models.BigIntegerField(null=True)
    update_date = models.DateTimeField(null=True)

    class Meta:
        db_table = ('TBL_GROUP')


class GroupRole(models.Model):
    group_id = models.BigIntegerField()
    role_id = models.BigIntegerField()

    class Meta:
        db_table = ('TBL_GROUP_ROLE')
        unique_together = (('group_id', 'role_id'),)


class GroupUser(models.Model):
    group_id = models.BigIntegerField()
    user_id = models.BigIntegerField()

    class Meta:
        db_table = ('TBL_GROUP_USER')
        unique_together = (('group_id', 'user_id'),)


class Role(models.Model):
    role_id = models.BigIntegerField()
    role_name = models.CharField(max_length=50)
    description = models.CharField(max_length=1500)
    use_yn = models.CharField(max_length=1, default='Y')
    delete_yn = models.CharField(max_length=1, default='N')
    create_user_id = models.BigIntegerField(null=True)
    create_date = models.DateTimeField(auto_now=True, null=True)
    update_user_id = models.BigIntegerField(null=True)
    update_date = models.DateTimeField(null=True)
    
    class Meta:
        db_table = ('TBL_ROLE')
        unique_together = (('role_id', 'role_name'),)


class User(models.Model):
    user_id = models.AutoField(primary_key=True)
    login = models.CharField(max_length=50)
    auth_code = models.CharField(max_length=100)
    full_name = models.CharField(max_length=100)
    email = models.CharField(max_length=100)
    last_auth_code_update_date = models.DateTimeField(auto_now=True, null=True)
    locale = models.CharField(max_length=50, default='ko')
    timezone = models.CharField(max_length=100, default='Asia/Seoul')
    datetime_pattern = models.CharField(max_length=50, default='YYYY-MM-DD HH:mm')
    status_id = models.BigIntegerField()
    delete_yn = models.CharField(max_length=50, default='N')
    login_fail_count = models.BigIntegerField(default=0)
    company = models.CharField(max_length=100, null=True, blank=True)
    nationality = models.CharField(max_length=100, null=True) 
    grade = models.CharField(max_length=100, null=True, blank=True)
    contact_no = models.CharField(max_length=100, null=True) 
    gender = models.CharField(max_length=10, null=True) 
    approval_id = models.BigIntegerField()
    create_user_id = models.BigIntegerField(null=True)
    create_date = models.DateTimeField(auto_now=True, null=True)
    update_user_id = models.BigIntegerField(null=True)
    update_date = models.DateTimeField(null=True)
    
    class Meta:
        db_table = ('TBL_USER')


class RoleUser(models.Model):
    user_id = models.BigIntegerField()
    role_id = models.BigIntegerField()
    start_date = models.DateTimeField(auto_now=True)
    end_date = models.DateTimeField(default='9999-01-01 00:00:00')
    
    class Meta:
        db_table = ('TBL_ROLE_USER')
        unique_together = (('user_id', 'role_id'),)


class Token(models.Model):
    token_key = models.CharField(max_length=100)
    token = models.CharField(max_length=255, primary_key=True)
    ip = models.CharField(max_length=100)
    expired_date = models.DateTimeField(null=True)
    created_date = models.DateTimeField(auto_now=True)
    
    class Meta:
        db_table = ('TBL_TOKEN')


class TermsUser(models.Model):
    terms_key = models.CharField(max_length=100)
    version = models.BigIntegerField()
    user_id = models.BigIntegerField()
    agree_yn = models.CharField(max_length=50, default='N')
    create_date = models.DateTimeField(auto_now=True, null=True)
    
    class Meta:
        db_table = ('TBL_TERMS_USER')


class LoginHistory(models.Model):
    id = models.AutoField(primary_key=True)
    login = models.CharField(max_length=50)
    full_name = models.CharField(max_length=100)
    ip = models.CharField(max_length=100, null=True)
    login_status = models.CharField(max_length=50, null=True)
    description = models.CharField(max_length=1500, null=True)
    event_date = models.DateTimeField(auto_now=True, null=True)
    
    class Meta:
        db_table = ('TBL_LOGIN_HISTORY')


class ErrorLog(models.Model):
    error_id = models.AutoField(primary_key=True)
    error_summary = models.CharField(max_length=300)
    contents = models.CharField(max_length=4000)
    create_date = models.DateTimeField(auto_now=True, null=True)
    
    class Meta:
        db_table = ('TBL_ERROR_LOG')

from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_v1_5
from base64 import b64decode
from base64 import b64encode

import bcrypt
import config


class RsaCipher:
    @staticmethod
    def rsa_encrypt(s):
        key = b64decode(config.PUBLIC_KEY)
        key = RSA.importKey(key)

        cipher = PKCS1_v1_5.new(key)
        cipher_text = b64encode(cipher.encrypt(bytes(s, "utf-8")))
        return cipher_text

    @staticmethod
    def rsa_decrypt(s):
        key = b64decode(config.PRIVATE_KEY)
        key = RSA.importKey(key)

        cipher = PKCS1_v1_5.new(key)
        plain_text = cipher.decrypt(b64decode(s), "Error while decrypting")
        return plain_text

    @staticmethod
    def bytes_to_bcrypt(b):
        return bcrypt.hashpw(b, config.BCRYPT_SALT.encode('UTF-8'))

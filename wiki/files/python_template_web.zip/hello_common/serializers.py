from rest_framework import serializers

from .models import CodeDetail, User, TermsUser, RoleUser


class CodeDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = CodeDetail
        fields = '__all__'


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = '__all__'


class TermsUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = TermsUser
        fields = '__all__'


class RoleUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = RoleUser
        fields = '__all__'

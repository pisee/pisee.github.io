from django.http import Http404, HttpResponseBadRequest

from django.forms.models import model_to_dict
from django.utils import timezone

from rest_framework.generics import ListAPIView
from rest_framework.views import APIView
from rest_framework.response import Response

from hello_common.models import CodeDetail, CodeGroup, User, Terms, TermsUser, RoleUser, Role, Message
from hello_common.serializers import CodeDetailSerializer, TermsUserSerializer
import config


# Create your views here.
class CodeView(APIView):
    def get(self, request):
        code_groups = CodeGroup.objects.filter(use_yn='Y')
        result = {}
        for code_group in code_groups:
            group_key = code_group.group_key
            code_details = CodeDetail.objects.filter(
                            group_id=code_group.group_id).order_by('code_order').values(
                            'code_id', 'code_key', 'default_name', 'message_group', 
                            'message_code', 'group_id', 'code_order', 'use_yn')
            result[group_key] = [elelment for elelment in code_details]       
        return Response(result)


class CodeDetailView(ListAPIView):
    serializer_class = CodeDetailSerializer

    def get_queryset(self):
        queryset = CodeDetail.objects.all()
        group_id = self.kwargs['group_id']
        if group_id is not None:
            queryset = queryset.filter(group_id=group_id)
        return queryset

    def list(self, request, group_id):
        qs = self.get_queryset()
        serializer = self.serializer_class(qs, many=True)
        return Response(serializer.data)        


class KeyView(APIView):
    def get(self, request):
        return Response(config.PUBLIC_KEY)


class TermsView(APIView):
    def get(self, request, terms_key):
        locale = request.GET.get('locale', '')
        published_yn = request.GET.get('publishedYn', '')
        version = request.GET.get('version', '1')

        queryset = Terms.objects.filter(terms_key=terms_key, locale=locale, published_yn=published_yn, version=version)
        
        result = model_to_dict(queryset.get())
        return Response(result)


class TermsUserView(APIView):
    def post(self, request, login):
        term_user_list = request.data
        try:
            user = User.objects.filter(login=login).get()
            user_id = user.user_id
        except User.DoesNotExist:
            raise Http404("User does not exist")
        for term_user_dict in term_user_list:
            term_user_dict['user_id'] = user_id
            
            term_user_serializer = TermsUserSerializer(data=term_user_dict)
            if term_user_serializer.is_valid():
                term_user_serializer.save()
            else:
                print(term_user_serializer.errors)
                return HttpResponseBadRequest()
        return Response()

    def get(self, request, login):
        try:
            user = User.objects.filter(login=login).get()
            queryset = TermsUser.objects.filter(user_id=user.user_id)
        except User.DoesNotExist:
            raise Http404("User does not exist")
        return Response(list(queryset.values()))


class UserRoleView(APIView):
    def get(self, request, login):
        queryset = User.objects.filter(login=login, delete_yn='N')
        try:
            user = queryset.get()
        except User.DoesNotExist:
            raise Http404("User does not exist")
        dt_now = timezone.now()
        role_users = RoleUser.objects.filter(user_id=user.user_id, start_date__lte=dt_now, end_date__gte=dt_now).values('role_id')

        result = []
        for role_user in role_users:
            role_id = role_user['role_id']
            roles = Role.objects.filter(role_id=role_id, use_yn='Y', delete_yn='N').values('role_id', 'role_name')
            result.extend(list(roles))
        return Response(result)


class MessageLangView(APIView):
    def get(self, request):
        return Response(config.APPLICATION_LANGUAGE)


class MessageView(APIView):
    def get(self, request):
        code_dic = {}
        for element in config.APPLICATION_LANGUAGE:
            code = element['lang']
            message_queryset = Message.objects.all().values('message_group', 'message_code', code)
            message_groups = {}
            for message in message_queryset:
                message_group = message['message_group']
                message_code = message['message_code']
                message = message[code]
                if message_group in message_groups:
                    message_groups[message_group].update({message_code:message})
                else:
                    message_groups[message_group] = {message_code:message}
            code_dic[code] = message_groups

        return Response(code_dic)

from django.urls import path
from hello_common.common import login_views

urlpatterns = [
    path("api/v1/login", login_views.LoginView.as_view()),
    path("api/v1/login/init", login_views.LoginView.as_view()),
    path("api/v1/login/current", login_views.UserSessionView.as_view()),
    path("api/v1/logout", login_views.LogoutView.as_view()),
]

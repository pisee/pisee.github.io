from django.urls import path
from hello_common.common import common_views

urlpatterns=[
    path("api/v1/codes", common_views.CodeView.as_view()),
    path("rest/v1/code/codegroup/<int:group_id>", common_views.CodeDetailView.as_view()),
    path("api/v1/key/public", common_views.KeyView.as_view()),
    path("api/v1/terms/<str:terms_key>", common_views.TermsView.as_view()),
    path("api/v1/terms/agreecheck/login/<str:login>", common_views.TermsUserView.as_view()),
    path("api/v1/terms/agreelist/login/<str:login>", common_views.TermsUserView.as_view()),
    path("api/v1/roles/user/<str:login>", common_views.UserRoleView.as_view()),
    path("api/v1/messages/lang", common_views.MessageLangView.as_view()),
    path("api/v1/messages", common_views.MessageView.as_view()),
]

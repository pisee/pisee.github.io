from django.http import Http404, HttpResponseForbidden
from django.core import signing

from rest_framework.views import APIView
from rest_framework.response import Response

import jwt
from time import time
from hello_common.models import User
from hello_common.rsa_cipher import RsaCipher
import config


# Create your views here.
class LoginView(APIView):
    def post(self, request):
        login = request.data.get('login', '')
        req_auth_code = request.data.get('auth_code', '')
        token = request.data.get('token', '')

        if token != '':
            decoded_token = jwt.decode(token.encode('utf-8'), config.JWT_SECRET, algorithms=['HS256'])
            login = decoded_token['login']
            expired_date = decoded_token['expired_date']

            if int(time()) < expired_date + (int(config.TOKEN_EXPIRED_TIME)*60*60):
                token = jwt.encode({'login': login, 'expired_date': int(time())}, config.JWT_SECRET, algorithm='HS256')
                request.session['token'] = token.decode('utf-8')
                return Response({'login': login, 'token': token.decode('utf-8')})
            else:
                return HttpResponseForbidden("User auth is failed")

        else:
            queryset = User.objects.filter(login=login, delete_yn='N')
            try:
                user = queryset.get()
                if self.compare_auth_code(req_auth_code, user.auth_code):
                    return HttpResponseForbidden("User auth is failed")
            except User.DoesNotExist:
                raise Http404("User does not exist")

            signed_user = signing.dumps({"user_id": user.user_id,
                                         "login": user.login, 'full_name': user.full_name,
                                         'email': user.email,
                                         'last_auth_code_update_date': user.last_auth_code_update_date.strftime(
                                             '"%Y-%m-%d %H:%M:%S %Z'),
                                         'locale': user.locale, 'timezone': user.timezone,
                                         'datetime_pattern': user.datetime_pattern,
                                         'nationality': user.nationality,
                                         'status_id': user.status_id,
                                         'login_fail_count': user.login_fail_count
                                         })

            token = jwt.encode({'login' : login, 'expired_date' : int(time())}, config.JWT_SECRET, algorithm='HS256')
            request.session['user'] = signed_user
            request.session['token'] = token.decode('utf-8')
            return Response({'login':login, 'token':token.decode('utf-8')})

    def compare_auth_code(self, req_auth_code, user_auth_code):
        decrypt_auth_code = RsaCipher.rsa_decrypt(req_auth_code)
        hashed_auth_code = RsaCipher.bytes_to_bcrypt(decrypt_auth_code)
        print(hashed_auth_code)
        user_auth_code = user_auth_code.encode('utf-8')
        return user_auth_code != hashed_auth_code

    def get(self, request):
        try:
            del request.session['user']
        except:
            pass

        try:
            del request.session['login']
        except:
            pass

        try:
            del request.session['token']
        except:
            pass

        return Response()


class LogoutView(APIView):
    def get(self, request):
        try:
            del request.session['user']
        except:
            pass

        try:
            del request.session['login']
        except:
            pass

        try:
            del request.session['token']
        except:
            pass

        return Response()


class UserSessionView(APIView):
    def get(self, request):
        try:
            signed_user = request.session['user']
            user = signing.loads(signed_user)
            return Response(user)
        except KeyError:
            try:
                token = request.session['token']

                decoded_token = jwt.decode(token.encode('utf-8'), config.JWT_SECRET, algorithms=['HS256'])
                login = decoded_token['login']
                expired_date = decoded_token['expired_date']

                if int(time()) < expired_date + (int(config.TOKEN_EXPIRED_TIME) * 60 * 60):
                    queryset = User.objects.filter(login=login, delete_yn='N')
                    try:
                        user = queryset.get()
                    except User.DoesNotExist:
                        raise Http404("User does not exist")

                    signed_user = signing.dumps({"user_id": user.user_id,
                                                 "login": user.login, 'full_name': user.full_name,
                                                 'email': user.email,
                                                 'last_auth_code_update_date': user.last_auth_code_update_date.strftime(
                                                     '"%Y-%m-%d %H:%M:%S %Z'),
                                                 'locale': user.locale, 'timezone': user.timezone,
                                                 'datetime_pattern': user.datetime_pattern,
                                                 'nationality': user.nationality,
                                                 'status_id': user.status_id,
                                                 'login_fail_count': user.login_fail_count
                                                 })

                    token = jwt.encode({'login': login, 'expired_date': int(time())}, config.JWT_SECRET,
                                       algorithm='HS256')
                    request.session['user'] = signed_user
                    request.session['token'] = token.decode('utf-8')
                    user = signing.loads(signed_user)
                    return Response(user)
                else:
                    return HttpResponseForbidden("User auth is failed")

            except KeyError:
                raise Http404("User does not exist")



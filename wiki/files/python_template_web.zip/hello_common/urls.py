from django.urls import path, include


app_name = 'hello_common'

urlpatterns = [
    path('', include('hello_common.common.common_urls')),
    path('', include('hello_common.common.login_urls')),
    path('', include('hello_common.user.user_urls')),
]


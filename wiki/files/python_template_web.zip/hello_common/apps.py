from django.apps import AppConfig


class HelloCommonConfig(AppConfig):
    name = 'hello_common'

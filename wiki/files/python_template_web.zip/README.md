# Python Template Project

1. [프로젝트 환경구성](guide/Setups.md)
2. [Coding Convention 및 Style 가이드](guide/Conventions.md)
3. [로깅 및 예외처리](guide/LoggingAndException.md)
4. [활용 가이드](guide/Application.md)

※ Test용 UI Frontend Project : https://code.sdsdev.co.kr/hello-world/vue-web-test

## 공통 가이드
- [Rest API Design Guide](https://code.sdsdev.co.kr/hello-world/guides/blob/development/ApiDesign.md)
- [Hello Visitor API/Table List](https://code.sdsdev.co.kr/hello-world/guides/blob/development/HelloVisitorAPIs.md)

# Coding Conventions & Style Guide  

## 1. Introduction
본 문서는 [PEP 8 Style Guide for Python Code](https://www.python.org/dev/peps/pep-0008/) 를 참고하였습니다.  
본 문서는 표준 라이브러리를 포함한 파이선 코드의 코딩 컨벤션을 제공합니다.  
많은 프로젝트들은 자체 coding style guide를 갖고 있습니다. 본 문서와 상충되는 내용이 있는경우, 프로젝트에 특화된 가이드가 우선합니다.  

## 2. A Foolish Consistency is the Hobgoblin of Little Minds
본 문서에서 제공하는 가이드는 코드의 가독성을 향상시키고 파이선 코드의 일관성을  향상시키기 위하여 작성되었습니다. coding style guide에서 일관성(consistency)은 매우 중요합니다. 하지만 본 문서의 style guide는 다음과 같은 경우 적용하지 않습니다.  
- style guide를 적용하여 가독성이 더 떨어지는 경우  
- 기존 다른 코드와 일관성이 떨어지는 경우
- old version 파이선 코드의 일관성(consistency)을 유지하기 위한 경우

## 3. Code layout
### 3.1 indentation
인덴테이션은 4개의 공백(space)을 사용합니다.  
연속라인(continuation line)은 구성 요소들을 vertically 또는 "hanging indent" 방식으로배치합니다.  
"hanging indent" 방식을 사용할 때는 다음 사항을 고려합니다.  
- 첫째줄에는 argument를 포함하지 않습니다.  
- argument들은 다음 문장과의 구별을 위하여 더 깊이 indentation합니다.  

```python
# Yes: More indentation included to distinguish this from the rest.
def long_function_name(
        var_one, var_two, var_three,
        var_four):
    print(var_one)

# Yes: Hanging indents should add a level.
foo = long_function_name(
    var_one, var_two,
    var_three, var_four)
```    

```python
# No: Arguments on first line forbidden when not using vertical alignment.
foo = long_function_name(var_one, var_two,
    var_three, var_four)

# No: Further indentation required as indentation is not distinguishable.
def long_function_name(
    var_one, var_two, var_three,
    var_four):
    print(var_one)
```

연속선(continuation lines)에서 4-space 규칙은 optional입니다.  
```python
# Hanging indents *may* be indented to other than 4 spaces.
foo = long_function_name(
  var_one, var_two,
  var_three, var_four)
```
if문에서 조건부 내용이 길어질 때, PEP는 멀티라인 조건부에 대한 indentaion 규칙을 정의하지 않고 상황에 따라 몇 가지 방식을 혼용하여 사용합니다.  
if 문에서 indentation 사용 예는 다음과 같습니다.  
```python
# No extra indentation.
if (this_is_one_thing and
    that_is_another_thing):
    do_something()
  
# Add a comment, which will provide some distinction in editors
# supporting syntax highlighting.
if (this_is_one_thing and
    that_is_another_thing):
    # Since both conditions are true, we can frobnicate.
    do_something()
  
# Add some extra indentation on the conditional continuation line.
if (this_is_one_thing
        and that_is_another_thing):
    do_something()
```
멀티라인 데이터 생성시 closing brace/bracket/parenthesis 은 리스트의 마직막 라인에 처음문자로 정의합니다.  
```python
my_list = [
    1, 2, 3,
    4, 5, 6,
    ]
 
result = some_function_that_takes_arguments(
    'a', 'b', 'c',
    'd', 'e', 'f',
    )
```

### 3.2 Tab or Spaces
indentation은 tab보다 space사용을 권장합니다.  
python3에서는 indentation에 tab과 space의 혼용을 허용하지 않습니다.  
python2 command line interpreter 기동시 -t 옵션은 tab과 space가 혼용되어 사용될경우 warning을 표시합니다.  
-tt 옵션은 error를 발생시킵니다. 이 옵션의 사용을 권장합니다.  

### 3.3 Maximum line length
모든 라인은 최대 길이를 79로 합니다. 주석이 없는 라인의 최대길이는 72로 합니다.  
대부분의 tool에서 기본 wrapping 기능은 코드의 visual 구조를 변형시켜서 코드를 이해하기 어렵게 할 수 있습니다. 최대 라인 길이를 길게하는것을 선호하는 경우, 최대 라인길이를 80에서 100으로 조정할 수 있습니다. python 표준 library는 보통 최대 라인 길이를 79 character로 제한합니다.  
긴라인의 경우 backslash 를 사용하여 line continuation을 하는 것도 좋은 방법입니다. long, multiple with 문장과 같이 implicit continuation을 사용할 수 없는 경우,  backslash를 사용합니다.  
```python
with open('/path/to/some/file/you/want/to/read') as file_1, \
     open('/path/to/some/file/being/written', 'w') as file_2:
    file_2.write(file_1.read())
```

### 3.4 Should a Line Break Before or After a Binary Operator
오랜동안 +와 같은 binary oprater 다음에 개행을 하였지만, 이 방식은 가독성을 떨어뜨릴 수 있습니다.  
```python
# No: operators sit far away from their operands
income = (gross_wages +
          taxable_interest +
          (dividends - qualified_dividends) -
          ira_deduction -
          student_loan_interest)
```
```python
# Yes: easy to match operators with operands
income = (gross_wages
          + taxable_interest
          + (dividends - qualified_dividends)
          - ira_deduction
          - student_loan_interest)
```
 python에서는 일관성 있게 규칙이 지켜지는 범위에서 operator 전이나 후에 개행을 사용할 수 있습니다.  

### 3.5 Blank lines
top level function과 class 정의는 2 line 개행(two blank lines)을 합니다.  
class에서 method 정의는 1 line 개행을 합니다.  
funtion에서 logical section을 나타내기 위하여 개행(blank line)을 사용합니다.  

### 3.6 Source file endcoding
<b>python 코드는 UTF-8 을 사용합니다(ASCII in python2)</b>  
python 3.0 이상에서는 다음과 같은 정책이 PEP3131에 설명되어 있습니다.  
python 표준 library에서 모든 identifier는 ASCII indetifier와 영문 단어를 사용합니다.  
non-ASCII 코드를 사용하는 테스트 케이스나 저자 이름과 같은 주석은 예외로 합니다.  
global open source 프로젝트도 유사한 정책을 사용합니다.  

### 3.7 imports
import문은 각각 별도의 라인에 정의합니다.  
```python
Yes: import os
     import sys
  
No:  import sys, os
```
from import에서는 다음과 같이 한 라인에 사용합니다
```python
from subprocess import Popen, PIPE
```
import 문은 파일의 최 상단에 정의합니다. import문은 모듈을 설명하는 comment 다음에, global 변수 선언 전에 정의합니다. import 문은 다음 순서로 정의합니다.  

1. Standard library imports.  
1. Related third party imports.  
1. Local application/library specific imports  

absolute import 문 사용을 권장합니다. absolute import는 보다 가독성이 좋고, import가 잘못되었을 경우 자세한 메시지를 제공합니다.  
```python
import mypkg.sibling
from mypkg import sibling
from mypkg.sibling import example
```
복잡한 package 구조의 모듈을 import할 때, absolute import는 복잡해 질수 있으므로 대안으로 relative import문을 사용할 수 있습니다.  
```python
from . import sibling
from .sibling import example
```
표준 library code는 가능한 한 복잡한 package 구조를 피하고 absolute import 방식을 사용합니다. class를 포함하고 있는 모듈에서 class를 import할때 다음과 같이 사용할 수 있습니다.  
```python
import myclass
import foo.bar.yourclass
  
# 또는
import myclass.MyClass
import foo.bar.yourclass.YourClass
```
Wildcard imports (```from <module> import *```)는 명확하지 않고, 코드를 읽는 사람에게 혼동을 줄 수 있으므로 가급적 사용하지 않습니다.  
예외 사용: public api의 부분으로서 내부 interface의 경우

### 3.8 Module Level Dunder Names  
```__all__```, ```__author__```, ```__version__``` 과 같은 module level dunder(앞뒤에 두 개의 밑줄이있는 이름)는 ```from __future__ imports```를 제외한 모든 import문 보다 앞에, 모듈을 설명하는 docstring 다음에 정의합니다.  
```python
"""This is the example module.
This module does stuff.
"""
from __future__ import barry_as_FLUFL
  
__all__ = ['a', 'b', 'c']
__version__ = '0.1'
__author__ = 'Cardinal Biggles'
  
import os
import sys
```
※ dunder : Double UNDERscore  

## 4. String quotes
python에서 single-quoted strings(') 과 double-quoted strings(")은 같은 역할을 합니다.  
PEP에서는 qutation character에 대한 특별한 권장사항은 없습니다.  
<b>단지 single 이나 double quote 문자를 사용하는 경우, backslash를 사용하지 않기 위하여 반대의 문자를 사용합니다.</b>

## 5. Whitespace in Expressions and Statements
### 5.1 Pet Peeves
다음과 같은 경우 과도한 whitespace를 사용하지 않습니다. 
- parentheses(괄호) 내부에 brackets(<) or brace({) 를 사용하는경우
    ```python
    Yes: spam(ham[1], {eggs: 2})
    No:  spam( ham[ 1 ], { eggs: 2 } )
    ```
- comma 다음에 close parenthesis(닫는괄호)가 오는 경우  
    ```python
    Yes: foo = (0,)
    No:  bar = (0, )
    ```
- comma, semicolon, colon 앞
    ```python
    Yes: if x == 4: print x, y; x, y = y, x
    No:  if x == 4 : print x , y ; x , y = y , x
    ```
- function call을 위한 open parenthesis(여는괄호) 앞에
    ```python
    Yes: spam(1)
    No:  spam (1)
    ```
- indexing이나 slicing을 위한 open parenthesis(여는괄호) 앞에
    ```python
    Yes: dct['key'] = lst[index]
    No:  dct ['key'] = lst [index]
    ```
- 다른 줄의 operator와 열을 맞추기 위하여 과도한 공백을 사용하는 경우
    ```python
    Yes:
    x = 1
    y = 2
    long_variable = 3
    
    No:
    x             = 1
    y             = 2
    long_variable = 3
    ```

### 5.2 Other Recommendations
- 문장 끝(trailing) 부분에 whitespace를 사용하지 않습니다. 보이지는 않지만 때때로 혼란스러운 경우가 있습니다. 몇몇 editor나 형상툴 precommit시에 trailing whitespace를 제거하는 경우도 있습니다.  
- 항상 이진 연산자 양쪽에 하나의 공백(whitespace)으로 감쌉니다.  
    assignment (```=```), augmented assignment (```+=```, ```-=``` etc.), comparisons (```==```, ```<```, ```>```, ```!=```, ```<>```, ```<=```, ```>=```, ```in```, ```not in```, ```is```, ```is not```), Booleans (```and```, ```or```, ```not```)

- 서로 다른 우선순위(priority)의 operator를 사용하는 경우, 가장 낮은 우선순위의 operator 주변에 whitespace 사용을 고려합니다.  
    ```python
    Yes:
    i = i + 1
    submitted += 1
    x = x*2 - 1
    hypot2 = x*x + y*y
    c = (a+b) * (a-b)

    No:
    i=i+1
    submitted +=1
    x = x * 2 - 1
    hypot2 = x * x + y * y
    c = (a + b) * (a - b)
    ```
- function annotation은 colon에 대한 일반 규칙을 사용합니다. arrow notation(->) 사용시에 space를 사용합니다.
    ```python
    Yes:
    def munge(input: AnyStr): ...
    def munge() -> AnyStr: ...
    
    No:
    def munge(input:AnyStr): ...
    def munge()->PosInt: ...
    ```
- keyword argument 나 default parameter value를 표시하는 = 오퍼레이터 사용 경우에, whitespace를 사용하지 않습니다.
    ```python
    Yes:
    def complex(real, imag=0.0):
        return magic(r=real, i=imag)
    
    No:
    def complex(real, imag = 0.0):
        return magic(r = real, i = imag)
    ```
- argument annotation을 default value와 결합하여 사용하는 경우에 = operator 주위에 space를 사용합니다.  
    ```python
    Yes:
    def munge(sep: AnyStr = None): ...
    def munge(input: AnyStr, sep: AnyStr = None, limit=1000): ...
    
    No:
    def munge(input: AnyStr=None): ...
    def munge(input: AnyStr, limit = 1000): ...
    ```
- 한 라인에 여러 문장(statement)을 사용하지 않습니다.
    ```python
    Yes:
    if foo == 'blah':
        do_blah_thing()
    do_one()
    do_two()
    do_three()
    
    No:
    if foo == 'blah': do_blah_thing()
    do_one(); do_two(); do_three()
    ```
- 작은 본문이있는 if / for / while을 같은 줄에 넣는 것이 좋을 수도 있지만, 절이 여러 절인 경우에는 절대 사용하지 않습니다. 또한 긴 줄을 접는 것을 피하도록 합니다.
    ```python
    # Rather Not
    if foo == 'blah': do_blah_thing()
    for x in lst: total += x
    while t < 10: t = delay()

    # Definitely not:
    if foo == 'blah': do_blah_thing()
    else: do_non_blah_thing()

    try: something()
    finally: cleanup()

    do_one(); do_two(); do_three(long, argument,
                                list, like, this)

    if foo == 'blah': one(); two(); three()
    ```

## 6. When to Use Trailing Commas
list형 변수를 사용할 경우, argument나 item은 시간이 지남에 따라 늘어날수 있으므로, 한 라인에 값을 정의하고 trailing comma를 사용합니다. 그리고 다음 라인에 자료의 끝을 나타내는 close parenthesis/bracket/brace 등을 사용합니다.  
trailing comma와 closing delimiters는 같은 라인에서 사용하지 않습니다.
```python
Yes:
FILES = [
    'setup.cfg',
    'tox.ini',
    ]
initialize(FILES,
           error=True,
           ) No:
FILES = ['setup.cfg', 'tox.ini',]
initialize(FILES, error=True,)
```

## 7. Comments
실재 코드 내용과 다른 주석은, 주석이 없는것 보다 못하므로, 항상 코드에 변경이 있을경우 주석을 최신내용으로 수정합니다.  
주석의 첫 번째 단어는 대문자로 시작합니다.  
그렇지 않으면 소문자로 시작하는 identifier와 혼동될 수 있습니다.  
주석문이 하나 이상의 단락(paragraph)으로 구성되어 있을때 block comment를 사용합니다.  여러 문장을 갖는 주석의 경우, 한 문장이 끝날때 period(.)를 찍고 두 개의 space 문자를 사용합니다.  
다른 언어권 사람이 코드를 읽을 가능성이 있는 경우, 비영어권의 파이선 개발자도 영어로 주석을 작성합니다.  

### 7.1 Block Comments
block 주석은 코드와 같은 level로 사용하고자 할때 사용합니다.  
block 주석은 각 라인은 ```#```과 space로 시작합니다.  
block 주석 내에서의 단락(paragraph)은 별도라인에 ```#```으로 표시합니다.  

### 7.2 Inline Comments
inline 주석은 파이선 문장과 같은 줄에 있습니다.  
inline 주석은 파이선 문장과 적어도 2개 이상의 space문자를 사용하여 분리합니다.  
inline 주석은 ```#```과 space 문자로 시작한다.  
코드내용이 명백한 경우 inline 주석은 사용하지 않습니다.  
```python
# 주석이 필요없는 경우
x = x + 1                 # Increment x
  
# 의미상으로 주석이 필요한 경우
x = x + 1                 # Compensate for border
```
### 7.3 Documentation Strings
- modules, functions, classes, methods와 같은 모든 public 모듈에 docstring을 작성합니다.  
- docstring은 non-public 메소드에서는 사용하지 않습니다. docstring은 ```"""```로 시작하고 ```"""```로 끝납니다.  
```python
"""Return a foobang
Optional plotz says to frobnicate the bizbaz first.
"""
```
- 한 줄 docstring은 시작과 끝을 나타내는 ```"""```을 한줄에 사용합니다.  

## 8. Naming Conventions
third party framework을 포함한 새로 작성하는 모듈은 다음의 명명규칙을 사용합니다.  
하지만 기 작성된 library가 다른 스타일의 명명규칙을 갖고 있으면 내부 일관성(internal consistency)이 우선됩니다.  

### 8.1 Overriding Principle
사용자에게 노출되는 public api에 대한 명명규칙은, 구현보다 사용자 관점에서 명명합니다.  

### 8.2 Descriptive: Naming Styles
다양한 명명규칙이 있는데, 이를 살펴보는 것이 명명규칙을 이해하는데 도움을 줍니다.  
다음과 같은 다양한 명명규칙이 있습니다.  
- ```b``` (single lowercase letter)
- ```B``` (single uppercase letter)
- ```lowercase```
- ```lower_case_with_underscores```
- ```UPPERCASE```
- ```UPPER_CASE_WITH_UNDERSCORES```
- ```CapitalizedWords``` (or CapWords, or CamelCase)
- ```mixedCase``` (initial lowercase character CapitalizedWords)
- ```Capitalized_Words_With_Underscores```<b>(ugly!)</b>
- ```st_mode```  
    관련된 단어의 short unique prefix 를 조합하여 사용하는 명명규칙도 있으나, python 코드에서는 잘 사용하지 않지만, 다음과 같은 경우에 사용할 수 있습니다.  
    예로, ```os.stat()``` 함수의 return 변수 명으로 ```st_mode```, ```st_size```, ```st_mtime``` 등을 사용하는데, 친숙하게 사용해왔던 POSIX 시스템 call 구조를 나타내기 위하여 사용하는 경우입니다.  
- ```_single_leading_underscore```: weak "internal use" indicator.
- ```single_trailing_underscore_```:Python Keyword와의 충돌을 피하기 위해 사용
    ```python
    Tkinter.Toplevel(master, class_='ClassName')
    ````
- ```__double_leading_underscore```: class attribute 명명 시
- ```__double_leading_and_trailing_underscore__```: magic objects 나 magic attributes를 사용자가 재정의 할때 사용  
    ```python
    __init__, __import__ , __file__ 
    ```
### 8.3 Prescriptive: Naming Conventions
#### 8.3.1 Names to Avoid
변수명에 'l'(소문자 l), 'O'(대문자 O), 'I'(대문자 I)와 같은 single charactor는 특정한 폰트에서 숫자 1,0과 구별되지 않는 경우가 있으므로 사용하지 않습니다.  

#### 8.3.2 ASCII Compatibility
표준 라이브러리에서 사용하는 identifier는 PEP3131문서에서 설명한 대로 ASCII 호환(compatible) 형식으로 정의합니다.  

#### 8.3.3 Package and Module Names
모듈명은 short, all-lowercase 형식으로 정의합니다. 가독성이 좋아지는 경우 underscore를 사용할 수 있습니다.  
패키지명은 short, all-lowercase 형식으로 정의합니다.  
C나 C++로 작성된 확장 모듈이 high level 파이선 interface를 제공하는 경우, C/C++ 모듈은 leading underscore 형식(e.g ```_socket```) 으로 정의합니다.  
builtin 모듈은 별도의 명명규칙을 적용합니다.  
대부분의 builtin 모듈은 single word 이거나 two word를 조합하여 사용합니다.  
CapWords 명명규칙은 exception 명이나 상수에 사용합니다.  

#### 8.3.4 Class Names
클래스 명은 일반적으로 CapWords 명명규칙을 사용합니다.  
인터페이스가 문서화(documented)되어 있고 주로 callable로 사용되는 경우 function 명명규칙을 사용합니다.  
builtin 명인 경우 별도의 명명규칙을 사용합니다.  
대부분의 builtin 명은 single word나, 두 단어를 조합한 CapWord 규칙을 사용합니다.  

#### 8.3.5 Type Variable Names
PEP484 문서에 소개된 type 변수명은 짧은명 CapWord 규칙을 사용합니다 (e.g : ```T```,```AnyStr```, ```Num```).  
covariant 나 contravariant 속성을 갖는 변수에는 접미사(suffix) ```_co``` 나 ```_contra``` 를 추가합니다.  
```python
from typing import TypeVar
  
VT_co = TypeVar('VT_co', covariant=True)
KT_contra = TypeVar('KT_contra', contravariant=True)
```
#### 8.3.6 Exception Names
exception은 클래스에 속하므로 class 명명규칙을 사용합니다.  
error exception 의 경우 이름의 끝에 접미사로 "Error" 를 추가합니다.  

#### 8.3.7 Global Variable Names
function 변수와 동일한 명명규칙을 사용합니다.  
다른 모듈에서 사용하도록 설계된 모듈(```from M import *```)에서 global export 용도로 변수를 사용하려면 ```__all__``` 에 변수를 선언하고, 사용을 원지 않는 경우 ```__all__```에 변수를 선언하지 않습니다.  
```python
__all__ = ['bar', 'baz']
```
non-public global 변수를 선언하는 다른 방법으로 변수명 앞에 underscore(_)를 사용합니다.  

#### 8.3.8 Function and Variable Names
function 명은 소문자를 사용합니다. 가독성이 향상되는 경우 underscore(_)문자로 단어를 조합하여 사용합니다.  
변수 명은 function명과 동일한 규칙을 사용합니다.  
기존에 존재하는 모듈의 명명규칙에서 대소문자를 혼합(mixedCase)하는 규칙을 사용하는 경우 이를 허용합니다.  

#### 8.3.9 Function and Method Arguments
instance 메소드의 첫번째 argument로 항상 ```self```를 정의합니다.  
class 메소드의 첫번째 argument로 항상 ```cls```를 정의합니다.  
function argument의 이름이 예약어(reserverd wordk)와 충돌하면, 약어를 사용하는것 보다 끝에 underscore를 붙여 사용하는 것이 더 바람직합니다
```python
class_ (better than clss)
```

#### 8.3.10 Method Names and Instance Variables
function 명명규칙과 동일하게 사용합니다 (소문자 단어, 혹은 underscore로 연결한 단어 조합)  
non-public 메소드나 instance 변수는 underscore(_) 문자로 시작합니다.  
subclass와 이름의 충돌을 피하기 위하여 두개의 leading underscore를 사용합니다.  
doubl underscore로 시작하는 이름은 python이 mangling을 수행합니다.  
```python
class A:
    def _single_method(self):
        pass
    def __double_method(self): # 맹글링을 위한 메서드
        pass
class B(A):
    def __double_method(self): # 맹글링을 위한 메서드
        pass
  
print(dir(A())) # ['_A_double_method', ..., '_single_method']
print(dir(B())) # ['_A_double_method', '_B_double_method', ..., '_single_method']
```
#### 8.3.11 Constants
상수는 일반적으로 모듈 levle로 정의합니다.  
대문자를 사용하며 단어를 underscore로 연결합니다.  
```python
MAX_OVERFLOW
```

#### 8.3.12 Designing for Inheritance
항상 클래스의 메소드나 어트리뷰트가 public일지 non-public 속성일지를 결정해야 합니다.  
non-public 사용을 우선적으로 고려합니다. non-public 속성을 public으로 변경하는 것이 더 수월하기 때문입니다.  
python에서는 진정한 private 속성을 지원하지 않기때문에 private 이라는 용어를 사용하지 않습니다.  
subclass API의 일 부분으로 사용되는 어트리뷰트 영영에 대하여도 고려가 필요합니다. 흔히 다른 언어에서 protected 속성이라고 합니다.  
다른 클래스로부터 상속(inherit)되거나 상위 클래스의 메소드를 확장하거나 수정이 필요할때 이 속성을 사용합니다.  
이런 클래스를 디자인할때 속성이 public인지 subclass API의 일부로 사용되어야 할지를 고려해야 합니다.  
public, non-public, subclass API와 관련한 가이드라인은 다음과 같습니다.  
- public attribute는 leading underscore를 사용하지 않습니다.
- public attribute가 예약어와 충돌시 trailing underscore 사용합니다.
- 단순한 public 데이터 속성의 경우, 복잡한 accessor나 mutator 메소드를 사용하지 않고 직접적으로 노출(expose)합니다.  
단순한 public 데이터 속성이 복잡한 기능으로 변경될때에 data 속성을 hide하는 기능을 구현합니다
- subclass에서 attribute가 사용되는 것을 원하지 않는경우, attribute 명은 double underscore(__)로 시작하게 명명합니다.  
attribute명이 double under score로 시작하면, python은 attribute명을 mangling하여 subclass에서 이 attribute의 충돌을 방지합니다.  

#### 8.3.13 Public and Internal Interfaces
하위버전 호환성(backward compatibitity)는 public interface에만 적용됩니다.  
따라서 public interface와 internal interface를 명확히 구분하는 것이 중요합니다.  
document된 interface는 명확히 interanl interface를 선언하지 않는한 public interface로 간주합니다.  
public interface attribute를 명확이 표시하기 위하여 ```__all__``` 를 사용합니다.  
모듈에 ```__all__``` list를 empty로 설정하는 것은  public API가 없다는 것을 의미합니다.  
```__all__``` list에 속성을 설정하였어도, packages, modules, classes, functions, attributes 등의 internal interface 명에 internal을 표시하기 위하여 '_'로 시작하는 prefix를 사용합니다.  
또한 package, module or class에 namingspace를 포함하고 있으면 internal interface를 의미합니다.  

## 9. Programming Recommendations
### 9.1  Recommendations
- python의 다른 구현체(e.g : PyPy, Jython, IronPython, Cython, Psyco, and such)를 고려하여 코드를 작성합니다.  
    예를 들어 ```a += b``` 이나 ```a = a + b``` 와 같은 recounting 문장은 python의 다른 구현체에서 지원하지 않을 수 있습니다.  
    성능이 중요한 code의 경우, ```''.join()``` 문을 대신 사용합니다. 
- 객체를 비교하는 경우 ```=``` 연산자 대신 ```is or is not``` 을 사용합니다.  
    예를 들어 ```if x is not None``` 문은 변수 x에 None대신 다른 값이 설정되었는지를 검사하는 조건문입니다.  
- ```not  ... is``` 표현 대신 ```is not``` operator를 사용합니다. 두 가지 표현 형식은 동일한 기능을 하나 후자가 가독성이 더 좋습니다. 
    ```python
    Yes:
    if foo is not None:
    
    No:
    if not foo is None:
    ```
- 함수 정의시 lamda expression 대신 def 문을 사용합니다.  
    ```python
    Yes:
    def f(x): return 2*x
    
    No:
    f = lambda x: 2*x
    ```
- ```BaseException``` 보다 ```Exception```으로 부터 파생된(derived) Exception을 사용합니다.  
    Exception class는 exception이 발생한 위치보다 발생한 exception 구분(distinction)에 중점을 두어 설계합니다.  
    exception은 "문제가 발생했다는 사실(a problem occured)" 보다는 "무엇이 잘못되었는지(what went wrong)" 를 확인하는 것이 보다 중요합니다.  
    error exception 명명 규칙은 접미사(suffix)에 Error를 사용합니다. non error exception은 별도의 suffix를 사용하지 않습니다.  
- 필요시 exception chaining 기능을 사용합니다.  
    python3에서 "rasise X from Y" 문장을 사용하면 이전에 발생한 exception 추적정보(traceback)를 사용할 수 있습니다.  
    python2에서 "raising X"나, python3에서 "rasing X from None"을 사용하면 이전 발생한 exception 정보를 새로 발생한 exception으로 replace합니다.  
    ```python
    # raise Exception from None
    try:
        raise ValueError
    except Exception as e:
        raise IndexError from None

    =>
    Traceback (most recent call last):
    File "py02.py", line 20, in <module>
        raise IndexError from None
    IndexError

    # raise Exception from e
    try:
        raise ValueError
    except Exception as e:
        raise IndexError from e

    =>
    Traceback (most recent call last):
    File "py02.py", line 26, in <module>
        raise ValueError
    ValueError
    The above exception was the direct cause of the following exception:
    Traceback (most recent call last):
    File "py02.py", line 28, in <module>
        raise IndexError from e
    IndexError
    ```
- python2에서 exception을 발생시킬때,  ```raise ValueError, 'message'``` 형식 대신 ```raise ValueError('message')``` 형식을 사용합니다.  
    python3에서 첫번째 형식의 문자을 지원하지 않습니다. 괄호(parenthesis)를 사용하는 형식은 exception argument가 길거나 formatting string을 갖고 있을때 line continuation characters를 필요로 하지 않습니다.  
- BaseException(bare except)은 SystemExit 와 KeyboardInterrupt exception을 감지하여, control-C를 사용하여 program을 제어하기 어렵고 문제해결을 어렵게 할 수 있으므로 사용을 자제합니다.  
    프로그램에서 발생하는 전체 에러를 감지(catch)하고 싶으면 ```except Exception```을 사용합니다. 
    ```python
    try:
        import platform_specific_module
    except ImportError:
        platform_specific_module = None
    ```
 
    가장좋은 방법은 bare 'except' 구분의 사용을 아래 두가지로 제한하는 것입니다.
    1. exception handler가 추적내용(traceback)을 print하거나 log로 남기면, 적어도 에러가 발생했다는 것을 감지할 수 있습니다.  
    1. exception 발생후 clean work와 같은 추가적인 조치가 필요할 경우, ```raise, try...finally``` 문을 사용합니다.  
- 
- exception은 모호하지 않은 명확한 명으로 정의합니다.  
    ```python
    try:
        process_data()
    except Exception as exc:
        raise DataProcessingFailedError(str(exc))
    ```
- try/except 문은 필요한 최소범의로 사용함으로서, 오류 발생시 대응이 용이합니다.
    ```python
    #Yes:
    try:
        value = collection[key]
    except KeyError:
        return key_not_found(key)
    else:
        return handle_value(value)
    
    #No:
    try:
        # Too broad!
        return handle_value(collection[key])
    except KeyError:
        # Will also catch KeyError raised by handle_value()
        return key_not_found(key)
    ```  
- resource 사용과 관련된 코드는 ```with``` 문을 사용하여, 자원 사용후 clean(혹은 release) 작업을 보장합니다.  
    try/finally 문도 이와 같은 경우 사용할 수 있습니다.  
- with문에서 function이나 method를 통하여 자원을 획득/해제 할때마다  Context Manager가 기동(invoke)됩니다.
    ```python
    #Yes:
    with conn.begin_transaction():
        do_stuff_in_transaction(conn)
       
    #No:
    with conn:
        do_stuff_in_transaction(conn)
    ```
- return문은 일관성 있게 사용합니다. function의 특정 부분에서 값을 반환하는 return을 사용하면 값이 return 되지 않는 위치에서도 ```return None```을 사용합니다. function의 끝부분에도 도달할수 있는 위치라면(if reachable) return 문을 사용합니다
    ```python
    #Yes:
    def foo(x):
        if x >= 0:
            return math.sqrt(x)
        else:
            return None
    
    def bar(x):
        if x < 0:
            return None
        return math.sqrt(x)
    
    #No:
    def foo(x):
        if x >= 0:
            return math.sqrt(x)
    
    def bar(x):
        if x < 0:
            return
        return math.sqrt(x)
    ```
- string module 보다 string method를 사용합니다. string method가 속도가 더 빠릅니다.
- 문자열의 prefix나 suffix 내용을 체크하기 위하여, string slicing대신 ```''.startswith()```나 ```''.endswith()``` 메소드를 사용합니다.
    ```python
    Yes: if foo.startswith('bar'):
    No: if foo[:3] == 'bar':
    ```
- object type 비교는 isinstance()를 사용합니다.  
    ```python
    Yes: if isinstance(obj, int):

    No:  if type(obj) is type(1):
    ```
    python2에서 문자열 객체 체크할때에 unicode 문자열일 경우를 염두에 두어야 합니다. str과 unicode는 basestring이라는 common base class를 갖고 있으므로 다음과 같이 체크할 수 있습니다.  
    ```python
    #python2
    if isinstance(obj, basestring):
    ```
    python3에서 ```unicode```와 ```basestring```은 존재하지 않고 ```str```만 있습니다. 또한 bytes object는 string 객제가 아니라 integer sequence 입니다.  
- sequence(strings, lists, tuples) 값 존재여부 체크는 empty sequnce는 false 값을 반환하는 것을 이용합니다.
    ```python
    Yes: if not seq:
        if seq:
    
    No:  if len(seq):
        if not len(seq):
    ```
- 문자열 끝 부분에 공백(trailing whitespace)를 사용하지 않습니다.  trailing whitespace는 시각적으로 구분하기 어렵고, 특정 editor에서는 trim이 됩니다.
- boolean 값 비교에 ```==``` 연산자를 사용하지 않습니다.  
    ```python
    Yes:   if greeting:
    No:    if greeting == True:
    Worse: if greeting is True:
    ```

### 9.2 Function Annotations
- 순방향 호환이 가능하도록 Python 3 코드의 함수 주석은 [PEP 484](https://www.python.org/dev/peps/pep-0484) 에서 개정한 구문을 사용하는 것이 좋습니다. 

### 9.3 Variable Annotations
- [PEP 526](https://www.python.org/dev/peps/pep-0526/) 에서 변수 주석을 소개했습니다. 뱐수 주석을 위한 style recommendations 는 위에 기술 된 Function Annotations와 유사합니다.
# 로깅, 예외처리

## 1. 로깅

장고 web framework에서 로깅은 다음과 같이 사용할 수 있습니다.  

```
ex)
# import the logging library
import logging

# Get an instance of a logger
logger = logging.getLogger(__name__)

def my_view(request, arg1, arg):
    ...
    logger.info('django info log!')
    
    if bad_mojo:
        # Log an error message
        logger.error('Something went wrong!')
```

## 1.1 로그 레벨
logger 인스턴스는 다음과 같은 로그 레벨이 있습니다.  
logger.debug(), logger.info(), logger.warning(), logger.error(), logger.critical()

## 1.2 로그 설정
로그 설정을 위하여 LOGGING 변수를 사용하며 형식은 dictionary 구조로 정의합니다.  
설정 내용은 django project의 settings.py 파일에 저장합니다.  
다음은 간단한 로그설정파일 예입니다.  
```
LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'handlers': {
        'console': {
            'class': 'logging.StreamHandler',
        },
    },
    'loggers': {
        'polls': {
            'handlers': ['console'],
            'level': 'INFO',
        },
    },
}
```
로거 이름이 polls인 logger는 console에 로그를 표시하며, 로그레벨은 INFO 입니다

다음은 좀더 다양한 설정이 있는 예입니다.  
```
LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'verbose': {
            'format': '{levelname} {asctime} {module} {process:d} {thread:d} {message}',
            'style': '{',
        },
        'simple': {
            'format': '{levelname} {message}',
            'style': '{',
        },
    },
    'handlers': {
        'console': {
            'level': 'INFO',
            'class': 'logging.StreamHandler',
            'formatter': 'simple'
        },
        'file': {
            'level': 'DEBUG',
            'class': 'logging.FileHandler',
            'filename': '/path/to/django/debug.log',
        },
    },
    'loggers': {
        'poll': {
            'handlers': ['console'],
            'level': 'ERROR',
            'propagate': False,
        },
        'hello_visitor': {
            'handlers': ['console', 'file'],
            'level': 'INFO',
        }
    }
}
```

- formatter :  로그 작업시 표시할 형식을 정의합니다.  
위의 예에서 formatter명 verbose는 simple보다 더 많은 내용을 표시합니다.  
- hadler : 로그 레벨, 로그매체(file, console등), formater(표시형식)등을 정의합니다
위의 예에서 hadler명 'console'은 콘솔에 로그를 표시하고, 'file'은 파일로 로그를 기록합니다.  
- loggers : 사용할 handler, 로그레벨등을 정의합니다


## 2. 예외처리
### 2.1 try ... exception ...
try excepion 문을 사용하여 예외처리를 합니다  
```
ex)
def divide(x, y):
    try:
        result = x / y
    except ZeroDivisionError:
        print("division by zero!")
    else:
        print("result is", result)
    finally:
         print("executing finally clause")
```
위의 예에서 예외가 발생한경우 해당 exception의 except 문을 실행합니다.  
예외가 발생하지 않 경우 else문을 실행합니다  
finally문을 정의한 경우 exception이 발생하여도 finally 문을 실행합니다.  

### 2.2 raise exception
raise문을 사용하여 예외를 발생시킬 수 있습니다  

```
ex)
try:
    raise NameError('HiThere')
except NameError:
    print('An exception flew by!')
    raise
```


### 2.3 사용자 정의 exception
사용자가 필요한 Exception class를 정의하여 사용할 수 있습니다.  
일반적으로 Exception class를 상속받아서 정의합니다.  
대부분의 예외는 표준 예외들의 이름들과 유사하게, "Error" 로 끝나는 이름으로 정의합니다.  

```
ex)
class InputError(Exception):
    def __init__(self, expression, message):
        self.expression = expression
        self.message = message
```
 
## 0. 참조 url
https://docs.djangoproject.com/en/2.1/topics/logging/#topic-logging-parts-loggers
https://docs.python.org/ko/3/tutorial/errors.html  



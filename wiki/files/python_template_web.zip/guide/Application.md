# Application Guide

## 1. project 생성

### 1.1 project 생성
django-admin을 사용하여 django 프로젝트를 생성합니다
```
> django-admin startproject python_template_web
```

### 1.2 server 실행
python manage.py 명령어를 사용하여 django server를 실행합니다
```
> python manage.py runserver
 January 29, 2019 - 10:46:11
 Django version 2.1.5, using settings 'python_template_web.settings'
 Starting development server at http://127.0.0.1:8000/
 Quit the server with CTRL-BREAK.
```

아래 내용은  포트를 7000으로 변경하여 서버를 실행한 예입니다
```
python manage.py runserver 7000
```

browser에서 "http://localhost:8000"를 실행합니다

![0](image/django.png)

### 1.3 app 생성 
python manage.py startapp 명령어를 실행하여 app을 생성합니다
```
> cd python_template_web
> python manage.py startapp hello_visitor
```

settings.py에서 INSTALLED_APPS 설정을 추가합니다
```
INSTALLED_APPS = [
    ...
    'hello_visitor',
    ....
```
## 2. model
### 2.1 model 작성
보통 app 생성시 기본으로 생성된 models.py 파일에 작성합니다  
다음은 model class 작성예입니다  

```
from django.db import models

class Visit(models.Model):
    visit_id = models.AutoField(primary_key=True)
    visit_status_id = models.BigIntegerField(default=1)
    visit_request_user_full_name = models.CharField(max_length=100)
    visit_start_date = models.DateTimeField(auto_now=True)
    visit_purpose = models.CharField(max_length=100, null=True)
    . . .
    class Meta:
        db_table = ('TBL_VISIT')
```

모델 클래스는 models.Model을 상속하여 작성합니다  
모델의 필드들을 작성합니다  
다음은 model class에서 사용할수 있는 field type, option 들 입니다
```
- model fied type
. primary key : AutoField
. 문자열 : CharField, TextField, SlugField
. 숫자 : IntegerField, BigIntegerField, DecimalField, FloatField 등
. 날짜/시간 : DateField, DateTimeField, TimeField

- model fied option
. primary_key=True
. null=True
. default=1
. max_length=100
. unique=True
. db_column

- meta class : 모델 클래스 전체에 속성을 적용합니다
. example
  class Meta:
    db_table = ('TBL_VISIT')
    ordering = ["-visit_id"]
```

모델작성에 필요한 상세한 문법은 다음 url을 참고합니다  
[https://docs.djangoproject.com/en/2.1/topics/db/models/]

### 2.2 relationships
Visit와 VisitUser 객체가 1대 N일때 아래와 같이 ForeignKey로 relationships을 정의합니다
```
class VisitUser(models.Model):
    visit_user_id = models.AutoField(primary_key=True)
    visit = models.ForeignKey(Visit, on_delete=models.CASCADE, db_column='VISIT_ID')
    visit_user_full_name = models.CharField(max_length=50)
    . . .
```

1:1 관계는 OneToOneField로 정의합니다  
```
ex)
class EntryDetail(models.Model):
    entry = models.OneToOneField(Entry, on_delete=models.CASCADE)
    details = models.TextField()
```

### 2.3 migrate
작성한 models.py 파일을 사용하여 table을 생성합니다  
```
> python manage.py makemigrations hello_visitor
> python manage.py sqlmigrate hello_visitor 0011
> python manage.py migrate hello_visitor
> python manage.py showmigrations hello_visitor
```
각 명령은 app별로 실행합니다  
app명을 주지 않으면 전체 프로젝트에 대하여 table을 생성합니다  
makemigrations은 migrate를 위한 메타파일을 생성합니다  
작업파일은 migration 폴더아래 순차적으로 파일이 생성됩니다
migrate 문은 실제 db 테이블에 작업을 실행합니다
sqlmigrate 문을 실행하여 작업할 ddl문을 확인할 수 있습니다  
sqlmigrate 문은 생략가능합니다
migration folder의 파일을 참조하여 변경내용을 인식하므로 다음작업을 위하여 보관이 필요합니다

## 3. query
### 3.1 query
Visit 모델객체의 전체 데이터를 조회합니다
```
qs = Visit.objects.all()
```
Visit 모델객체에서 delete_yn='N'인 값을 조회합니다
```
qs = Visit.objects.filter(delete_yn='N')
```
해당 query set의 count를 조회합니다
```
tot_cnt = qs.count()
```
해당 query set을 visit_id의 역순으로 조회합니다
```
qs = qs.order_by('-visit_id')
```
해당 query set을 offet부터 limit갯수만큼 paging(slicing)합니다
```
qs = qs[offset:limit]
```

filter문에서 다음과 같은 조건을 사용할 수 있습니다
```
. and 조건
  queryset = 모델명.queryset.all()
  queryset = queryset.filter(필드1=값1, 필드2=값2)
  queryset.filter(Q(필드1=값1) & Q(필드2=값2))
. or 조건
  queryset.filter(Q(필드1=값1) | Q(필드2=값2))
. 비교조건
  필드명__lt = 값   (필드명 < 값)
  필드명__lte = 값  (필드명 <= 값_
  필드명__gt = 값   (필드명 > 값)
  필드명__startswith = 값  (필드명 like "값%")
  필드명__endswith = 값    (필드명 like "%값")
  필드명__contains = 값    (필드명 like "%값%")
```

다음과 같은 방법으로 실행 sql문을 조회할수 있습니다
```
# queryset의 sql문 표시
qs.query

# 실행한 sql문을 index로 선택하여 조회할 수 있습니다
from django.db import connection
. . .
connection.queries[-1]
```

query 관련하여 상세한 내용은 다음 url을 참조합니다  
https://docs.djangoproject.com/en/2.1/topics/db/queries/

### 3.2 relationships

Visit 객체와 relationship이 있는 VisitUser 객체를 조회합니다
```
visit = Visit.objects.get(visit_id=pk)
vu_list = visit.visituser_set.all()
```

추가 예제
```
# VisitCar 객체의 visit_car_gate='E' 인 Visit 객체 조회
qs = Visit.objects.filter(visitcar__visit_car_gate='E')
print(qs.first().visit_id)
print(connection.queries[-1])

sql문 =>
SELECT "TBL_VISIT"."visit_id", ...
FROM "TBL_VISIT" INNER JOIN "TBL_VISIT_CAR" ON 
("TBL_VISIT"."visit_id" = "TBL_VISIT_CAR"."VISIT_ID") 
WHERE "TBL_VISIT_CAR"."visit_car_gate" = \'E\' ...

# Visit 객체의 visit_id=1 인 VisitCar 객체 조회
qs = VisitCar.objects.filter(visit__visit_id=1)
print(qs.first().visit_car_id)
print(connection.queries[-1])

sql문 =>
SELECT "TBL_VISIT_CAR"."visit_car_id", ...
FROM "TBL_VISIT_CAR" 
WHERE "TBL_VISIT_CAR"."VISIT_ID" = 1 ...

# visit_car_id=1 인 VisitCar 객체에서 Visit 객체를 참조
visitCar = VisitCar.objects.get(visit_car_id=1)
print(visitCar.visit.visit_id)
print(connection.queries[-2:-1])

sql문 =>
SELECT "TBL_VISIT_CAR"."visit_car_id", ...
FROM "TBL_VISIT_CAR" 
WHERE "TBL_VISIT_CAR"."visit_car_id" = 1

SELECT "TBL_VISIT"."visit_id", ...
FROM "TBL_VISIT" 
WHERE "TBL_VISIT"."visit_id" = 1'

# visit_car_id=1 인 VisitCar 객체에서 Visit 객체를 참조(join)
visitCar = VisitCar.objects.select_related().get(visit_car_id=1)
print(visitCar.visit.visit_id)
print(connection.queries[-1])
sql문 =>
SELECT "TBL_VISIT_CAR"."visit_car_id", ...
"TBL_VISIT"."visit_id", ...
FROM "TBL_VISIT_CAR" INNER JOIN "TBL_VISIT" ON 
("TBL_VISIT_CAR"."VISIT_ID" = "TBL_VISIT"."visit_id") 
WHERE "TBL_VISIT_CAR"."visit_car_id" = 1'
```

python shell을 사용하여 간단히 query문을 실행하여 결과를 조회할 수 있습니다
```
> python manage.py shell
>>> from hello_visitor.models import Visit
>>> v = Visit.objects.first()
>>> v.visit_id
1
>>>
```
relationships query 관련하여 상세한 내용은 다음 url을 참조합니다
https://docs.djangoproject.com/en/2.1/topics/db/queries/#related-objects


### 3.3 save
Visit 객체 data를 create합니다
```
visit = Visit()
visit.visit_request_user_id = user_id
...
visit.save()
```

Visit 객체 data를 update 합니다
```
visit = Visit.objects.get(visit_id=pk)
visit.visit_status_id = status_id
visit.save()
```

### 3.4 delete
Visit 객체 data를 삭제합니다
```
visit = Visit.objects.get(visit_id=pk)
visit.delete()
```

### 3.4 native sql
다음과 같은 형식으로 native sql문을 사용할 수 있습니다
```
ex)
	sql_stmt = '''
    SELECT V.VISIT_ID
        , V.VISIT_REQUEST_USER_ID
        . . .
    FROM TB_VISIT V
    WHERE DELETE_YN = 'N'
    AND V.VISIT_REQUEST_USER_ID = %s
    '''
        
    args = [visit_request_user_id]
    . . .

	with connection.cursor() as cursor:
    	cursor.execute(sql, args)
        visit_list = []  
        for row in cursor.fetchall():
        	visit_dic    = {
            	'visitId': row[0],
                'visitRequestUserId' : row[1],
                . . .
            }
            visit_list.append(visit_dic)

	return visit_list
```

### 3.5 extra
```
ex)
qs = Visit.objects.extra(
    select={'code_name': 'default_name'}, 
    tables=['tbl_code_detail'], 
    where=['tbl_code_detail.group_id=7', 'code_key=visit_status_id'] )
    print(qs.first().code_name)
```

### 3.6 transaction
class method에 다음과 같이 명시적(explicitly)으로 transaction을 설정할 수 있습니다
```
class VisitCreateCar(APIView):
	@transaction.atomic
	def post(self, request):
```

function에도 transaction을 설정할수 있습니다
```
@transaction.atomic
def viewfunc(request):
    # This code executes inside a transaction.
    do_stuff()
```

settings.py파일에 전체 database에 대하여 transaction을 설정하는 방법도 있습니다  

상세한 내용은 다음 url을 참조합니다
[https://docs.djangoproject.com/en/2.1/topics/db/transactions/]

### 3.7 db connection
django framework은 PostgreSQL, SQLite, MySQL, Oracle등의 database를 지원합니다
다음은 settings.py에서 database 설정예입니다  
```
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': os.path.join(BASE_DIR, 'db.sqlite3'),
    }
}
```

django framework은 "Persistent connections"이라는 db접속방식을 사용합니다  
이 방식에서는 CONN_MAX_AGE라는 값을 사용합니다  

상세한 내용은 다음 url을 참조합니다
[https://docs.djangoproject.com/en/2.1/ref/databases/]

## 4. url 정의
보통 urls.py 파일에 web request url을 정의합니다  
아래의 예는 'api/v1/visits/history'라는 url을 요청하면  
visit_views.py 파일에 있는 VisitList class의 as_view를 호출합니다  

```
urlpatterns = [
    path('api/v1/visits/history', visit_views.VisitList.as_view()),
    path('api/v1/visits/approval', visit_views.VisitList.as_view()),
    path('api/v1/visits', visit_views.VisitList.as_view()),
    . . .
]
```

project(예:python_template_web) urls.py파일 에 app별 url파일을 정의해야합니다
```
urlpatterns = [
    path('admin/', admin.site.urls),
    path('admin', admin.site.urls),

    path('', include('hello_visitor.urls')),
    path('', include('hello_common.urls')),
    path('swagger-ui', schema_view),
]
```

## 5. view 작성

### 5.1 class based view
아래 class는 django 기반 rest api view 작성예입니다  

```
# ex)
class VisitList(APIView):
    def get(self, request):
        resp_dict = self.list_visit(request.GET)
        #print('# resp : ', resp_dict)
        return Response(resp_dict)

    def post(self, request):
        print('# request data visit : ', request.data) #dictionary
        v_ser = self.create_visit(request.data)
        print('# visit_id ', v_ser.data['visit_id'])
        
        return Response({"visitId": v_ser.data['visit_id']})
        
    def list_visit(self, data):
        visit_request_user_id = data.get('visitRequestUserId', '') #신청자
        . . .
        qs = Visit.objects.filter(delete_yn='N')
        . . .
        visit_list = []
        for row in qs:
            row_dict = VisitSerializer(row).data 	#serializer : model object => dict
            . . .
            visit_list.append(row_dict)
            
        resp_dict = {'content': visit_list, 'totalPages' : tot_page, ...}
        return resp_dict
```

django rest_framework의 APIView를 상속하여 class를 작성합니다  
```
from rest_framework.views import APIView
. . .
class VisitList(APIView):
```

client에서 호출한 METHOD(get/post/put/delete) 에 따라  
각각 class view의 get/post/put/delete method가 실행됩니다 
```
def get(self, request):
def post(self, request):
def put(self, request, pk, status_id):
def delete(self, request, pk):
```

get method의 경우 request.GET(dictionary data type)을 사용하여 요청한 data를 얻을수 있습니다  
```
visit_request_user_id = request.GET['visitRequestUserId']
# key값 not found시 처리 예
visit_request_user_id = request.GET('visitRequestUserId', '')
```

post method의 경우 request.data(dictionary data type)을 사용하여 요청한 data를 얻을수 있습니다  
request.data는 request body에 있는 data를 dictionary 형태로 변환한 data입니다  

```
visit_request_user_id = request.data['visitRequestUserId']
# key값 not found시 처리 예
visit_request_user_id = request.data.get('visitRequestUserId', '')

```

url의 data를 key 값으로 매핑하여 data로 사용할 수 있습니다
```
#urls.py
path('api/v1/visits/<int:pk>', visit_views.VisitDetail.as_view()),	#get, delete

#views.py
def delete(self, request, pk):
```

처리한 dictionary형태의 data를 Response 객체에 넣어 client로 return합니다  
resopnse 객체는 dictionary data를 json 객체로 변환하여 client로 return합니다  
```
resp_dict = {'content': visit_list, 'totalPages' : tot_page, 'totalElements': tot_cnt}
return Response(resp_dict)
```

dictionary to model object setting 예제
```
v = Visit();
v.visit_request_user_id = req_data['visitRequestUserId']
v.visit_request_user_full_name = req_data['visitRequestUserFullName']
. . .
v.save() 
```

query object to dictionary setting 예제
```
qs = Visit.objects.filter(delete_yn='N')
. . .
visit_list = []
for row in qs:
	visit_dic    = {
    	'visitId': row.visit_id,
        'visitRequestUserId' : row.visit_request_user_id,
        'visitRequestUserFullName': row.visit_request_user_full_name,
        . . .
    }
    visit_list.append(visit_dic)
```

dictionary와 object간의 상호 변환은 Serializer를 사용하여 간편하게 작업할 수 있습니다  

### 5.2 function based view

다음은 rest api를 function based view로 작성한 예입니다  
client에서 url=visit/list, method=get으로 호출하면  
views.py 파일의 visit_list_func_exam을 실행하고 request.method == 'GET' 인  
if문으로 분기합니다  
```
#urls.py
path('visit/list', views.visit_list_func_exam),

#views.py
@api_view(['GET','POST'])
def visit_list_func_exam(request):
    if request.method == 'GET':
        print('# request : ', request.GET)
        visit_id = request.GET.get('visit_id', '')
        qs = Visit.objects.filter(visit_id=visit_id)
        vs = VisitSerializer(qs, many=True)
        return Response(vs.data)
    elif request.method == 'POST':
        return Response({})
        pass
```

### 5.3 generic view

다양한 generic view를 활용하여 편리하게 작업할 수 있습니다  
```
#class VisitListViewExam(generics.ListCreateAPIView):
class VisitListViewExam(mixins.ListModelMixin,
                  mixins.CreateModelMixin,
                  generics.GenericAPIView):
    #queryset = Visit.objects.first()
    serializer_class = VisitSerializer

    def get_queryset(self):
        queryset = Visit.objects.all()
        visit_id = self.request.query_params.get('visit_id', None)
        if visit_id is not None:
            queryset = queryset.filter(visit_id=visit_id)
            
        return queryset

    def list(self, request):
        qs = self.get_queryset()
        serializer = self.serializer_class(qs, many=True)
        return Response(serializer.data)        
        
    def create(self, request):
        serializer_data = request.data

        serializer = self.serializer_class(data=serializer_data)
        serializer.is_valid(raise_exception=True)
        serializer.save()

        return Response(serializer.data)
```

django rest framework관련 상세한 내용은 다음 url을 참조합니다
[https://www.django-rest-framework.org/]

## 6. serializer
serializer는 model 객체나 queryset 객체를 dictionary type으로 변환(serialize)하거나  
dictionary type을 model 객체로 변환(deserialize)합니다  

다음은 ModelSerializer를 상속하여 작성한 serializer 예입니다  
```
class VisitSerializer(serializers.ModelSerializer):
    class Meta:
        model = Visit
        fields = "__all__"
```

다음은 dictionary data를 model 객체로 변환하는 예입니다  
```
v_dict = req.GET
. . .
v_ser = VisitSerializer(data=v_dict)
valid = v_ser.is_valid()
v_ser.save()
```

다음은 queryset 객체를 dictionary type으로 변환하는 예입니다  
```
qs = Visit.objects.filter(delete_yn='N')
. . .
visit_list = []
for row in qs:
	row_dict = VisitSerializer(row).data 	#serializer : model object => dict
    . . .
    visit_list.append(row_dict)
resp_dict = {'content': visit_list, 'totalPages' : tot_page, ...}

```

## 7. rest api 테스트
작성한 rest service는 swagger나, django에서 제공하는 browsable api를 사용하여  
편리하게 테스트할 수 있습니다

## 7.1 VisitList class 테스트
VisitList에는 get과 post 메소드가 구현되어 있습니다
VisitList를 다음 url로 browser에서 호출하여 get method를 테스트합니다
http://localhost:8000/api/v1/visits/history?page=0&size=15&visitStatusId=&visitRequestUserId=1
post method가 구현되어 있으므로 하단의 입력박스에 json 형식의 입력데이터를 넣고 post 버튼을 클릭하면  
post method를 테스트 할 수 있습니다  
![1](image/bapi_vlist.png)

## 7.2 VisitDetail class 테스트
VisitDetail에는 get과 delete 메소드가 구현되어 있습니다
VisitDetail을 다음 url로 browser에서 호출하여 get method를 테스트합니다
http://localhost:8000/api/v1/visits/1
delete method가 구현되어 있으므로 상단에 delete 버튼을 확인할수 있습니다  
![1](image/bapi_vdetail.png)


## 8. 설정파일

### 8.1 setttings.py

```
# 오류시 디버그 페이지 정보를 보여줍니다
# 운영시 DEBUG = False로 설정해야 합니다
DEBUG = True
```

```
# app을 추가한 경우 INSTALLED_APPS에 설정합니다
INSTALLED_APPS = [
    'django.contrib.admin',
    . . .
    
    'corsheaders', #django-cors-headers
    'rest_framework',
    'rest_framework.authtoken',
    'rest_framework_swagger',
    'hello_visitor',
    'hello_common',
]
```

```
# session engine의 종류를 설정합니다
# session data는 db, file등 다양한 매체에 저장할 수 있습니다
# 아래 설정은 signed_cookies 방식의 세션엔진을 사용합니다
SESSION_ENGINE = "django.contrib.sessions.backends.signed_cookies" 
```

```
# database 정보를 설정합니다
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': os.path.join(BASE_DIR, 'db.sqlite3'),
    }
}
```

```
# cors 관련 설정 입니다
# cors시 허용할 ip, domain등을 설정하며 허용된 site에서 요청이 오면,
# 허락을 수락하는 cors header를 리턴합니다
# CORS_ALLOW_CREDENTIALS = True는 cookie 정보 송수신을 허용합니다

CORS_ORIGIN_ALLOW_ALL = True
#CORS_ORIGIN_WHITELIST = ( '127.0.0.1:9091', 'hello.com') 
CORS_ALLOW_CREDENTIALS = True
```

```
# 시스템에서 사용할 renderer와 parser class를 설정합니다
# 아래 설정으로 reqquest data를 camel case에서 snake case로 일괄 변환합니다
# json data return시 key값을 snake case에서 camel case로 일괄 변환합니다
REST_FRAMEWORK = {
    'DEFAULT_RENDERER_CLASSES': (
        'djangorestframework_camel_case.render.CamelCaseJSONRenderer',
    ),
    'DEFAULT_PARSER_CLASSES': (
        'djangorestframework_camel_case.parser.CamelCaseFormParser',
        'djangorestframework_camel_case.parser.CamelCaseMultiPartParser',
        'djangorestframework_camel_case.parser.CamelCaseJSONParser',
    ),
}
```

```
# 기타설정 : url 호출시 url 맨 끝에 '/'를 붙이지 않습니다
APPEND_SLASH=False
```

### 8.2 requirements.txt

pip install 명령어를 사용하여 필요한 패키지를 설치합니다
requirements.txt 파일에 필요한 패키지 목록을 작성하고 아래의 명령어를 실행하면  
일괄적으로 패키지가 설치됩니다
```
> pip install -r requirements.txt

# requirements.txt
six==1.12.0
Django==2.1.7
django-composite-foreignkey==1.1.0
django-cors-headers==2.4.1
djangorestframework==3.9.2
djangorestframework-camel-case==1.0.3
django-rest-swagger==2.2.0
pytz==2018.9
pycryptodome==3.8.0
bcrypt==3.1.6
```

### 8.3 DJANGO_SETTINGS_MODULE

서버 실행시 사용할 setting.py 파일 정보를 지정하는 환경변수입니다 
DJANGO_SETTINGS_MODULE 변수는 다음과 같은 파일(방법)에서 설정합니다  
```
# manage.py : 개발시 설정
  os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'python_template_web.settings')
# wsgy.py : 운영시 설정
  os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'python_template_web.settings')
# "python manage.py runserver" 에서 지정
  > python manage.py runserver --settings=myproject.settings.prod
```

## 0. django admin
django에서 제공하는 admin app을 사용하여 model에 대한 data를 편리하게 조회 변경할 수 있습니다
admin app을 사용하기 위한 설정방법은 다음과 같습니다  
```
1. admin app 사용 table 생성
  > python manage.py migrate admin
2. settings.py파일의 INSTALLED_APPS에 admin app 등록 확인
   project 생성시 기본으로 설정되어 있습니다
   INSTALLED_APPS = [
      'django.contrib.admin',
      ...
   ]
3. admin.py에 추가한 model을 다음과 같이 등록합니다
  admin.site.register(Visit)
```

browser에서 다음  url을 입력하여(http://localhost:8000/admin/) 사용합니다  

![0](image/django_admin.png)

## 0. 추가항목
. . .

## 0. 참조 url 모음
django : https://docs.djangoproject.com/en/2.1/  
django resst framework : https://www.django-rest-framework.org/  
model : https://docs.djangoproject.com/en/2.1/topics/db/models/  
query : https://docs.djangoproject.com/en/2.1/topics/db/queries/  
query relationships : https://docs.djangoproject.com/en/2.1/topics/db/queries/#related-objects  
transaction : https://docs.djangoproject.com/en/2.1/topics/db/transactions/  
db connection : https://docs.djangoproject.com/en/2.1/ref/databases/  



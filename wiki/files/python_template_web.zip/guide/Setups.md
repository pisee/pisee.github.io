# Project 환경구성

## 1. 파이선설치

파이선이나 "파이선 아나콘다 배포판"을 설치합니다.  
파이선 다운로드 url : https://www.python.org/downloads  
아나콘다 배포판 url : https://www.anaconda.com  
파이선 버전 : 3.7  
아나콘다 배포판은 수학과 과학 분야에서 사용되는 여러 패키지들을 묶어 놓은 파이썬 배포판으로서 SciPy, Numpy, Matplotlib, Pandas 등을 비롯한 많은 패키지들을 포함하고 있습니다

## 2. 파이선 IDE 설치
"Visual Studio code" 나 "pyCharm"을 설치합니다

### 2.1 Python extension for Visual Studio Code 설치
다운로드 url : https://code.visualstudio.com


### 2.2 PyCharm 설치
다운로드 url : https://www.jetbrains.com/pycharm

### 2.3 Visual Studio Code 파이선 환경 설정
관련 url https://code.visualstudio.com/docs/python/python-tutorial 을 참조합니다.

#### python interpreter 설정
```
menu -> view -> command pallete 이동
python: select interpreter 에서 설치된 python interpreter 선택
```
![](image/select_interpreter.png)

## 3. Django project 생성
### pip install
pip를 사용하여 django framework 관련 패키지를 설치합니다
```
> pip install --proxy http://70.10.15.10:8080 pylint
> pip install --proxy http://70.10.15.10:8080 django
> pip install --proxy http://70.10.15.10:8080 djangorestframework
```

또는 c:/Users/<사용자>/pip 폴더 pip.ini 파일에 proxy 정보를 설정할 수 있습니다  
pip install시 --proxy 옵션을 생략할 수 있습니다
```
ex)
[global]
proxy = http://70.10.15.10:8080
cert = C:\\Users\\SDS\\SDS.crt
trusted-host = pypi.python.org
           pypi.org
           files.pythonhosted.org
```

### django project 생성
django-admin을 사용하여 django 프로젝트를 생성합니다
```
> django-admin startproject python_template_web
```

### django server 실행
python manage.py 명령어를 사용하여 django server를 실행합니다
```
> python manage.py runserver
 January 29, 2019 - 10:46:11
 Django version 2.1.5, using settings 'python_template_web.settings'
 Starting development server at http://127.0.0.1:8000/
 Quit the server with CTRL-BREAK.
```

browser에서 "http://localhost:8000"를 실행합니다

![0](image/django.png)

### django app 생성 
python manage.py startapp 명령어를 실행하여 app을 생성합니다
```
> cd python_template_web
> python manage.py startapp hello_visitor
```

## 4. Django project 구조
### python_template_web project 구조 
django project를 생성하면 다음과 같은 파일과 폴더 template이 자동으로 생성됩니다  
프로젝트 이름과 같은 app(ex: python_template_web)이 subfolder에 생성됩니다
```
python_template_web/
    manage.py
    python_template_web/
        __init__.py
        settings.py
        urls.py
        wsgi.py
```
settings.py : project 환경 설정 파일  
urls.py : app별 url 설정파일

### hello_visitor app 구조 
django app을 생성하면 다음과 같은 파일template이 자동으로 생성됩니다
```
hello_visitor/
    __init__.py
    admin.py
    apps.py
    migrations/
        __init__.py
    models.py
    tests.py
    views.py	
```
apps.py : app 설정파일  
models.py : model 관련 코드 작성 파일  
views.py : view 관련 코드 작성 파일

## 5. git project 와 VS Code 연동
cmd 창에서 git clone 명령을 실행하여 프로젝트 파일을 가져옵니다  
git project url은 다음과 같습니다  
https://code.sdsdev.co.kr/hello-world/python_template_web.git
```
> git clone https://code.sdsdev.co.kr/hello-world/python_template_web.git
```
VS Code에서 open folder로 clone받은 폴더를 오픈합니다

### VS code에서 소스 commit
소스 수정후 VS Code 에서 commit 후 git repository에 push 할 수 있습니다
![0](image/git_menu.png)  
왼쪽 측면의 source control tab을 선택하면 explorer 상단에 commit등 git 관련 명령어를 실행할 수 있습니다  
참조 url : https://code.visualstudio.com/docs/editor/versioncontrol

## 6. 참조 url
https://docs.djangoproject.com/en/2.1/  
https://www.django-rest-framework.org/  


